# Interactive page (static, runs in the browser)

| File | Purpose | Publish it? |
|---|---|---|
| `index.html` | The interactive page (self-contained CSS + JS, no dependencies) | yes |
| `sim.js` | JavaScript port of `simulation.py` / `experiment.py` | yes |
| `test_parity.mjs`, `gen_parity_fixture.py`, `parity_fixture.json` | Proves `sim.js` matches the Python simulator | no (repo only; the fixture is ~1 MB) |

## Deploying to GitHub Pages

Copy `index.html` and `sim.js` into the folder your site publishes (keep them side by side; `index.html`
imports `./sim.js`). Nothing runs server-side. To embed in an existing page, either link to it or put it in an
`<iframe>`; the page follows the viewer's light/dark setting, or set `data-theme="dark"|"light"` on `<html>`.

## Running locally

ES modules are blocked on `file://`, so serve the folder:

```bash
cd web && python3 -m http.server 8000     # then open http://localhost:8000
```

## Keeping the port honest

```bash
python3 web/gen_parity_fixture.py   # ground truth from the Python simulator
node web/test_parity.mjs            # needs Node 18+
```

The test compares, against Python on fixed seeds: the raw random stream (MT19937, `gauss`, `choice`, `uniform`),
full 36-month states and traces for 25 runs (including bankruptcy, low-governance and compliance-penalty
cases), per-run outcomes over ~1,000 seeds, the Monte Carlo summaries, and the pure risk formulas on a dense
input grid. Regenerate the fixture whenever `simulation.py` changes on purpose, then fix `sim.js` until it passes.
