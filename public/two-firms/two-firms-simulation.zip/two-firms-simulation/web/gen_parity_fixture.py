#!/usr/bin/env python3
"""Generate ground-truth fixtures from the Python simulator for test_parity.mjs.

Run from anywhere:  python3 web/gen_parity_fixture.py
Writes web/parity_fixture.json. Regenerate whenever simulation.py's behaviour changes on purpose.
"""
import json
import random
import sys
from dataclasses import asdict, replace
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))

from experiment import paired  # noqa: E402
from simulation import (AI_NATIVE, DEFAULT_ASSUMPTIONS, SCENARIOS, TRADITIONAL, Assumptions, Scenario,  # noqa: E402
                        bad_build_probability, churn_rate, debt_penalty, incident_probability, monte_carlo,
                        run_once)

RNG_SEEDS = [0, 1, 42, 12345, 42 * 73 + 11, 2**32 - 1, 2**32, 2**40 + 3]
N_DRAWS = 500


def rng_stream(seed: int) -> list[float]:
    """Mixed draws; op = i % 5. Must match test_parity.mjs exactly."""
    r = random.Random(seed)
    out = []
    for i in range(N_DRAWS):
        op = i % 5
        if op == 0:
            out.append(r.random())
        elif op == 1:
            out.append(r.gauss(0, 1))
        elif op == 2:
            out.append(r._randbelow(96))
        elif op == 3:
            out.append(r.uniform(4, 10))
        else:
            out.append(r.gauss(1, .065))
    return out


def firm_state(f) -> dict:
    return {
        'cash': f.cash, 'customers': f.customers, 'product': f.product, 'fit': f.fit,
        'debt': f.debt, 'trust': f.trust, 'governance': f.governance,
        'incidents': f.incidents, 'bad_builds': f.bad_builds,
        'delivered_work': f.delivered_work, 'cumulative_profit': f.cumulative_profit,
        'alive': f.alive, 'min_cash': f.min_cash,
    }


def run_case(label: str, seed: int, scenario, models=None, assumptions: dict | None = None) -> dict:
    """`scenario` is a name from SCENARIOS or an inline dict of Scenario fields."""
    sc = SCENARIOS[scenario] if isinstance(scenario, str) else Scenario(**scenario)
    a = DEFAULT_ASSUMPTIONS if assumptions is None else Assumptions(**assumptions)
    firms, history = run_once(seed, 36, sc, True, models=models, assumptions=a)
    return {'label': label, 'seed': seed, 'scenario': scenario, 'assumptions': assumptions,
            'models': None if models is None else [asdict(m) for m in models],
            'firms': [firm_state(f) for f in firms], 'history': history}


def formula_grid() -> dict:
    """Pure formulas on a dense grid, including states no end-to-end run reaches often (or at all)."""
    events = ['normal', 'new-demand', 'outage', 'price-pressure', 'compliance']
    gov = [0, 10, 20, 30, 40, 50, 54.9, 55, 55.1, 59.9, 60, 60.1, 64, 65, 66, 80, 100]
    fit = [0, 20, 40, 50, 54.9, 55, 55.1, 60, 80, 100]
    dbt = [0, 10, 19.9, 20, 20.1, 27.9, 28, 28.1, 40, 60, 80, 100, 153, 200]
    trust = [0, 10, 30, 50, 64.9, 65, 65.1, 80, 100]
    review = [0, 0.25, 0.55, 0.8, 1.0]
    return {
        'debt_penalty': [[d, debt_penalty(d)] for d in dbt],
        'debt_penalty_start': [[d, t, debt_penalty(d, t)] for d in dbt for t in (10, 20, 35, 80)],
        'bad_build': [[g, f, r, e, bad_build_probability(g, f, r, e)]
                      for g in gov for f in fit for r in review for e in events],
        'incident': [[d, g, e, b, incident_probability(d, g, e, b)]
                     for d in dbt for g in gov for e in events for b in (False, True)],
        'incident_threshold': [[d, g, e, b, th, incident_probability(d, g, e, b, th)]
                               for d in dbt for g in (0, 40, 54.9, 55, 70) for e in events for b in (False, True)
                               for th in (15, 28, 45, 90)],
        'churn': [[t, d, i, churn_rate(t, d, i)] for t in trust for d in dbt for i in (False, True)],
        'churn_variants': [[t, d, i, base, th, churn_rate(t, d, i, base, th)]
                           for t in trust for d in dbt for i in (False, True)
                           for base, th in ((.007, 28), (.03, 28), (.014, 15), (.04, 60))],
    }


def main():
    cases = []
    for scenario in SCENARIOS:
        for seed in (42, 43, 1000):
            cases.append(run_case(f'{scenario}/{seed}', seed, scenario))
    cases.append(run_case('ablation/capacity100', 42, 'baseline',
                          (replace(AI_NATIVE, capacity=100), TRADITIONAL)))
    cases.append(run_case('aa/traditional', 42, 'baseline', (TRADITIONAL, TRADITIONAL)))
    cases.append(run_case('bankruptcy', 3, 'baseline',
                          (replace(AI_NATIVE, monthly_staff_cost=2_000_000), TRADITIONAL)))

    # Non-default shared assumptions (model v0.2). Each exercises one coefficient end to end.
    for label, over in {
        'debt-per-build-high': dict(debt_per_build=.10), 'debt-per-build-low': dict(debt_per_build=.03),
        'review-effect-zero': dict(review_effect=0.0), 'review-effect-high': dict(review_effect=.8),
        'debt-threshold-50': dict(debt_threshold=50), 'debt-threshold-15': dict(debt_threshold=15),
        'throttle-10': dict(throttle_start=10), 'churn-high': dict(churn_base=.04),
        'money': dict(arpu=60, overhead=80_000, cost_per_customer=20),
        'downturn': dict(downturn_start=13, downturn_months=12, downturn_mult=.5),
        'thin-cash-bankrupt': dict(start_cash=50_000, overhead=150_000),
        'combined': dict(debt_per_build=.09, review_effect=.5, debt_threshold=35, churn_base=.02,
                         arpu=90, downturn_start=5, downturn_months=6, downturn_mult=.4),
    }.items():
        cases.append(run_case(f'assume/{label}', 42, 'baseline', assumptions=over))
    cases.append(run_case('assume/ai-friction+combined', 7, 'ai-friction',
                          assumptions=dict(debt_per_build=.05, churn_base=.02, overhead=60_000)))

    # Stress cases. Normal parameters never push governance below 66, so these exist to exercise the
    # low-governance branches (compliance penalty < 65, bad-build term < 60, incident term < 55), the
    # review clamp at both ends, shocks disabled, other cadences, and double bankruptcy.
    # Zero fixed costs keep the huge-capacity firm alive, so its low-governance branches actually run.
    free = dict(monthly_staff_cost=0, token_cost_per_work=0, ai_tool_cost=0)
    huge = lambda cap: replace(AI_NATIVE, capacity=cap, defect_factor=0.2, review_strength=1.0, **free)  # noqa: E731
    for seed in (300, 249, 208):
        cases.append(run_case(f'stress/lowgov-cap6000/{seed}', seed, 'baseline', (huge(6000), TRADITIONAL)))
    # Compliance penalty (governance < 65 after a compliance month) is reachable only via a stale allocation:
    # with cadence 3 a compliance month that is not a decision month reuses an earlier new-demand allocation.
    for seed in (5, 6):
        cases.append(run_case(f'stress/compliance-penalty/{seed}', seed, 'baseline',
                              (AI_NATIVE, replace(TRADITIONAL, capacity=300, defect_factor=0.2, **free))))
    cases.append(run_case('stress/review-clamp-hi', 42, dict(name='x', native_review_delta=0.9)))
    cases.append(run_case('stress/review-clamp-lo', 42, dict(name='x', native_review_delta=-0.9)))
    cases.append(run_case('stress/no-compliance-shocks', 42, dict(name='x', compliance_shocks=False)))
    cases.append(run_case('stress/cadence-2-vs-6', 42, 'baseline',
                          (replace(AI_NATIVE, decision_cadence=2), replace(TRADITIONAL, decision_cadence=6))))
    cases.append(run_case('stress/both-bankrupt', 5, dict(name='x', market_growth_mult=0.0),
                          (replace(AI_NATIVE, monthly_staff_cost=450_000),
                           replace(TRADITIONAL, monthly_staff_cost=450_000))))

    # Bulk cases: final per-run outcomes over hundreds of seeds. Rare branches (low governance, compliance
    # penalty) fire too seldom in a handful of runs for a probability coefficient to be pinned down.
    bulk_defs = {
        'bulk/baseline': ('baseline', None, range(100, 400)),
        'bulk/ai-friction': ('ai-friction', None, range(100, 300)),
        'bulk/lowgov-cap6000': ('baseline', (huge(6000), TRADITIONAL), range(1, 301)),
        'bulk/compliance-penalty': ('baseline', (AI_NATIVE, replace(TRADITIONAL, capacity=300, defect_factor=0.2, **free)),
                                    range(1, 301)),
    }
    mixed = dict(debt_per_build=.08, review_effect=.5, debt_threshold=24, churn_base=.02, arpu=90,
                 cost_per_customer=12, overhead=60_000, downturn_start=10, downturn_months=8, downturn_mult=.5)
    bulk_defs['bulk/assume-mixed'] = ('baseline', None, range(100, 400), mixed)
    bulk = {}
    for label, d in bulk_defs.items():
        scn, mods, seeds = d[:3]
        over = d[3] if len(d) > 3 else None
        a = DEFAULT_ASSUMPTIONS if over is None else Assumptions(**over)
        rows = []
        for sd in seeds:
            f, _ = run_once(sd, 36, SCENARIOS[scn], models=mods, assumptions=a)
            rows.append([f[0].cash, f[1].cash, f[0].incidents, f[1].incidents,
                         f[0].bad_builds, f[1].bad_builds, f[0].customers, f[1].customers,
                         int(f[0].alive), int(f[1].alive)])
        bulk[label] = {'scenario': scn, 'assumptions': over,
                       'models': None if mods is None else [asdict(m) for m in mods],
                       'seed_start': seeds.start, 'n': len(seeds), 'rows': rows}

    summaries = {}
    for name, sc in SCENARIOS.items():
        s = monte_carlo(200, 36, sc, 42)
        s.pop('assumed_parameters')
        summaries[name] = s

    pairs = {
        'baseline_300': paired((AI_NATIVE, TRADITIONAL), SCENARIOS['baseline'], runs=300),
        'ai-friction_300': paired((AI_NATIVE, TRADITIONAL), SCENARIOS['ai-friction'], runs=300),
        'defect1.0_300': paired((replace(AI_NATIVE, defect_factor=1.0), TRADITIONAL),
                                SCENARIOS['baseline'], runs=300),
        'assume-mixed_300': paired((AI_NATIVE, TRADITIONAL), SCENARIOS['baseline'], runs=300,
                                   assumptions=Assumptions(**mixed)),
    }

    fixture = {'n_draws': N_DRAWS,
               'rng': {str(s): rng_stream(s) for s in RNG_SEEDS},
               'cases': cases, 'bulk': bulk, 'grid': formula_grid(), 'summaries': summaries, 'paired': pairs}
    out = HERE / 'parity_fixture.json'
    out.write_text(json.dumps(fixture), encoding='utf-8')
    print(f'wrote {out} ({out.stat().st_size / 1e6:.2f} MB): {len(cases)} run cases, '
          f'{len(RNG_SEEDS)} rng seeds, {len(summaries)} summaries, {len(pairs)} paired checks')


if __name__ == '__main__':
    main()
