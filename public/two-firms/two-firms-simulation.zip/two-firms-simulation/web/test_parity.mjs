// Parity test: sim.js must reproduce the Python simulator on fixed seeds.
//   python3 web/gen_parity_fixture.py && node web/test_parity.mjs
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import {
  PyRandom, runOnce, monteCarlo, paired, pyRound, AI_NATIVE, TRADITIONAL, SCENARIOS,
  debtPenalty, badBuildProbability, incidentProbability, churnRate,
} from './sim.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const fx = JSON.parse(readFileSync(path.join(here, 'parity_fixture.json'), 'utf8'));

let checks = 0;
const failures = [];
const fail = msg => failures.push(msg);

// relative tolerance for float fields (libm differences are ~1 ulp; we allow 1e-9)
function close(a, b, tol = 1e-9) {
  checks++;
  return Math.abs(a - b) <= tol * Math.max(1, Math.abs(a), Math.abs(b));
}
function same(a, b) { checks++; return a === b; }

// ------------------------------------------------------------- 1. raw RNG stream
let maxRngErr = 0;
for (const [seedStr, expected] of Object.entries(fx.rng)) {
  const r = new PyRandom(Number(seedStr));
  expected.forEach((want, i) => {
    const op = i % 5;
    let got;
    if (op === 0) got = r.random();
    else if (op === 1) got = r.gauss(0, 1);
    else if (op === 2) got = r.randbelow(96);
    else if (op === 3) got = r.uniform(4, 10);
    else got = r.gauss(1, .065);
    maxRngErr = Math.max(maxRngErr, Math.abs(got - want));
    // exact for integer-valued ops and raw random(); tiny tolerance where libm (cos/sin/log) is involved
    const exact = op === 0 || op === 2 || op === 3;
    if (exact ? !same(got, want) : !close(got, want, 1e-12)) {
      fail(`rng seed=${seedStr} draw=${i} op=${op}: got ${got} want ${want}`);
    }
  });
}

// ------------------------------------------------------------- 2. full run states + histories
const STATE_FIELDS = ['cash', 'customers', 'product', 'fit', 'debt', 'trust', 'governance',
  'delivered_work', 'cumulative_profit'];
const COUNTERS = { incidents: 'incidents', bad_builds: 'badBuilds' };
const ROUND = { customers: 0, cash_gbp: 0, monthly_profit_gbp: 0, revenue_gbp: 0, cost_gbp: 0,
  product: 2, fit: 2, debt: 2, trust: 2, governance: 2, work: 1 };
const CAMEL = { delivered_work: 'deliveredWork', cumulative_profit: 'cumulativeProfit' };

let worstRel = 0;
for (const c of fx.cases) {
  const models = c.models ? c.models : null;
  const sc = typeof c.scenario === 'string' ? SCENARIOS[c.scenario]
    : { name: 'x', native_capacity_mult: 1, native_defect_mult: 1, native_tool_mult: 1, native_review_delta: 0,
        market_growth_mult: 1, compliance_shocks: true, ...c.scenario };
  const { firms, history } = runOnce(c.seed, 36, sc, { keepHistory: true, models });
  firms.forEach((f, i) => {
    const want = c.firms[i];
    for (const k of STATE_FIELDS) {
      const got = f[CAMEL[k] ?? k];
      const rel = Math.abs(got - want[k]) / Math.max(1, Math.abs(want[k]));
      worstRel = Math.max(worstRel, rel);
      if (!close(got, want[k])) fail(`${c.label} slot${i} ${k}: got ${got} want ${want[k]}`);
    }
    for (const [k, jk] of Object.entries(COUNTERS)) {
      if (!same(f[jk], want[k])) fail(`${c.label} slot${i} ${k}: got ${f[jk]} want ${want[k]}`);
    }
    if (!same(f.alive, want.alive)) fail(`${c.label} slot${i} alive: got ${f.alive} want ${want.alive}`);
  });
  if (!same(history.length, c.history.length)) {
    fail(`${c.label} history length: got ${history.length} want ${c.history.length}`);
    continue;
  }
  history.forEach((h, idx) => {
    const w = c.history[idx];
    for (const k of ['month', 'event', 'company', 'incidents_cumulative', 'bad_builds_cumulative', 'alive']) {
      if (!same(h[k], w[k])) fail(`${c.label} row${idx} ${k}: got ${h[k]} want ${w[k]}`);
    }
    for (const [k, nd] of Object.entries(ROUND)) {
      // pyRound reproduces Python's round() exactly, so rounded history fields must match exactly
      checks++;
      if (pyRound(h[k], nd) !== w[k]) fail(`${c.label} row${idx} ${k}: got ${pyRound(h[k], nd)} want ${w[k]}`);
    }
  });
}

// ------------------------------------------------------------- 2b. bulk per-run outcomes
for (const [label, b] of Object.entries(fx.bulk)) {
  const sc = SCENARIOS[b.scenario];
  for (let i = 0; i < b.n; i++) {
    const { firms } = runOnce(b.seed_start + i, 36, sc, { models: b.models });
    const want = b.rows[i], tag = `${label} seed=${b.seed_start + i}`;
    const got = [firms[0].cash, firms[1].cash, firms[0].incidents, firms[1].incidents,
      firms[0].badBuilds, firms[1].badBuilds, firms[0].customers, firms[1].customers,
      +firms[0].alive, +firms[1].alive];
    got.forEach((g, j) => {
      const ok = [2, 3, 4, 5, 8, 9].includes(j) ? same(g, want[j]) : close(g, want[j]);
      if (!ok) fail(`${tag} col${j}: got ${g} want ${want[j]}`);
    });
  }
}

// ------------------------------------------------------------- 2c. pure formulas on a dense grid
// No libm involved, so these must match Python to the last bit.
const exact = (label, got, want) => { checks++; if (got !== want) fail(`grid ${label}: got ${got} want ${want}`); };
for (const [d, w] of fx.grid.debt_penalty) exact(`debt_penalty(${d})`, debtPenalty(d), w);
for (const [g, f, r, e, w] of fx.grid.bad_build) exact(`bad_build(${g},${f},${r},${e})`, badBuildProbability(g, f, r, e), w);
for (const [d, g, e, b, w] of fx.grid.incident) exact(`incident(${d},${g},${e},${b})`, incidentProbability(d, g, e, b), w);
for (const [tr, d, i, w] of fx.grid.churn) exact(`churn(${tr},${d},${i})`, churnRate(tr, d, i), w);

// ------------------------------------------------------------- 3. Monte Carlo summaries
for (const [name, want] of Object.entries(fx.summaries)) {
  const got = monteCarlo(200, 36, SCENARIOS[name], 42);
  const flat = (o, p = '') => Object.entries(o).flatMap(([k, v]) =>
    typeof v === 'object' ? flat(v, `${p}${k}.`) : [[`${p}${k}`, v]]);
  const g = Object.fromEntries(flat(got));
  for (const [k, v] of flat(want)) {
    if (!same(g[k], v)) fail(`summary ${name} ${k}: got ${g[k]} want ${v}`);
  }
}

// ------------------------------------------------------------- 4. paired analysis
const PAIR_MODELS = {
  'baseline_300': [AI_NATIVE, TRADITIONAL, 'baseline'],
  'ai-friction_300': [AI_NATIVE, TRADITIONAL, 'ai-friction'],
  'defect1.0_300': [{ ...AI_NATIVE, defect_factor: 1.0 }, TRADITIONAL, 'baseline'],
};
for (const [name, want] of Object.entries(fx.paired)) {
  const [a, b, sc] = PAIR_MODELS[name];
  const got = paired([a, b], SCENARIOS[sc], 300);
  if (!same(pyRound(got.win_fraction, 4), want.win_fraction)) fail(`paired ${name} win_fraction`);
  if (!close(pyRound(got.win_ci95, 4), want.win_ci95, 1e-9)) fail(`paired ${name} win_ci95`);
  if (Math.abs(Math.round(got.mean_cash_diff) - want.mean_cash_diff) > 1) fail(`paired ${name} mean_cash_diff`);
  if (Math.abs(Math.round(got.median_cash_diff) - want.median_cash_diff) > 1) fail(`paired ${name} median_cash_diff`);
  if (Math.abs(got.mean_incidents_slot0 - want.mean_incidents_slot0) > 0.0051) fail(`paired ${name} incidents0`);
}

// ------------------------------------------------------------- report
console.log(`checks: ${checks}   failures: ${failures.length}`);
console.log(`largest relative error in any raw state field: ${worstRel.toExponential(2)}`);
if (failures.length) {
  failures.slice(0, 25).forEach(f => console.log('  FAIL ' + f));
  if (failures.length > 25) console.log(`  ... and ${failures.length - 25} more`);
  process.exit(1);
}
console.log('PARITY OK: sim.js matches the Python simulator on every fixture.');
