#!/usr/bin/env python3
"""Sensitivity analysis for the two-firm simulator (model v0.2).

Two different kinds of uncertainty are kept apart on purpose:

  * Statistical uncertainty: how much a number moves if you rerun the same model with fresh random
    draws. It shrinks with more runs. Reported as 95% intervals and as the spread of the same
    statistic across independent seed blocks.
  * Parameter sensitivity: how much the answer moves when an *assumption* changes. It does not shrink
    with more runs, because the assumptions are invented. Reported as tornado ranges, tipping points
    and a rank correlation across random assumption sets.

Every comparison uses paired random conditions: for a given seed both firms face the identical market
events and demand draws, and the same seeds are reused for every parameter setting (common random
numbers), so differences between settings are not sampling noise.

Standard library only. Usage:  python3 sensitivity.py --output results     (about 10 minutes on 4 cores)
"""
from __future__ import annotations

import argparse
import json
import math
import random
import statistics as st
from dataclasses import replace
from multiprocessing import Pool
from pathlib import Path

from experiment import paired, spearman
from simulation import (AI_NATIVE, DEFAULT_ASSUMPTIONS, MODEL_VERSION, SCENARIOS, TRADITIONAL,
                        Assumptions, run_once)

BASE = SCENARIOS['baseline']
RUNS = 2000
SEED_BLOCKS = [42, 10_042, 20_042, 30_042]  # block 0 is the seed range every earlier number used
BAND = 0.20  # tornado: each assumption moved to 80% and 120% of its baseline value

# Every assumption that can be moved. `group` says whose it is; `base` is its baseline value.
#   ai.*     the AI-heavy firm's own value          trad.*  the traditional firm's own value
#   shared.* a coefficient both firms are subject to (see simulation.Assumptions)
# `tooling` scales the AI-heavy firm's fixed tooling spend and its per-unit token cost together.
PARAMS = {
    'ai.capacity':           dict(label='AI-heavy delivery capacity', group='AI-heavy', base=AI_NATIVE.capacity),
    'ai.defect_factor':      dict(label='AI-heavy defect factor', group='AI-heavy', base=AI_NATIVE.defect_factor),
    'ai.review_strength':    dict(label='AI-heavy review strength', group='AI-heavy', base=AI_NATIVE.review_strength),
    'ai.monthly_staff_cost': dict(label='AI-heavy staff cost', group='AI-heavy', base=AI_NATIVE.monthly_staff_cost),
    'ai.tooling':            dict(label='AI-heavy tooling and token spend', group='AI-heavy', base=1.0),
    'trad.capacity':         dict(label='Traditional delivery capacity', group='Traditional', base=TRADITIONAL.capacity),
    'trad.defect_factor':    dict(label='Traditional defect factor', group='Traditional', base=TRADITIONAL.defect_factor),
    'trad.review_strength':  dict(label='Traditional review strength', group='Traditional', base=TRADITIONAL.review_strength),
    'trad.monthly_staff_cost': dict(label='Traditional staff cost', group='Traditional', base=TRADITIONAL.monthly_staff_cost),
    'shared.debt_per_build': dict(label='Technical debt per unit of build work', group='Shared', base=DEFAULT_ASSUMPTIONS.debt_per_build),
    'shared.review_effect':  dict(label='How much review cuts that debt', group='Shared', base=DEFAULT_ASSUMPTIONS.review_effect),
    'shared.debt_threshold': dict(label='Debt level where incidents begin', group='Shared', base=DEFAULT_ASSUMPTIONS.debt_threshold),
    'shared.churn_base':     dict(label='Base monthly customer churn', group='Shared', base=DEFAULT_ASSUMPTIONS.churn_base),
    'shared.arpu':           dict(label='Revenue per customer', group='Shared', base=DEFAULT_ASSUMPTIONS.arpu),
    'shared.cost_per_customer': dict(label='Running cost per customer', group='Shared', base=DEFAULT_ASSUMPTIONS.cost_per_customer),
    'shared.overhead':       dict(label='Common monthly overhead', group='Shared', base=DEFAULT_ASSUMPTIONS.overhead),
}


def build(over: dict) -> tuple[tuple, Assumptions]:
    """Turn {'ai.capacity': 150, ...} into (models, assumptions). Unlisted keys stay at baseline."""
    ai, trad, shared = {}, {}, {}
    tooling = 1.0
    for key, v in over.items():
        side, name = key.split('.', 1)
        if key == 'ai.tooling':
            tooling = v
        elif side == 'ai':
            ai[name] = v
        elif side == 'trad':
            trad[name] = v
        else:
            shared[name] = v
    if tooling != 1.0:
        ai['ai_tool_cost'] = AI_NATIVE.ai_tool_cost * tooling
        ai['token_cost_per_work'] = AI_NATIVE.token_cost_per_work * tooling
    return (replace(AI_NATIVE, **ai), replace(TRADITIONAL, **trad)), replace(DEFAULT_ASSUMPTIONS, **shared)


def gap(over: dict, seed: int = SEED_BLOCKS[0], runs: int = RUNS, scenario=BASE) -> dict:
    models, a = build(over)
    return paired(models, scenario, runs=runs, seed=seed, assumptions=a)


def _task(args):
    over, seed, runs = args
    return gap(over, seed, runs)


def breakeven_bisect(f, lo: float, hi: float, iters: int = 9) -> float | None:
    """Value in [lo, hi] where f changes sign, by bisection. None if f has the same sign at both ends."""
    flo, fhi = f(lo), f(hi)
    if flo == 0:
        return lo
    if fhi == 0:
        return hi
    if flo * fhi > 0:
        return None
    for _ in range(iters):
        mid = (lo + hi) / 2
        fm = f(mid)
        if fm == 0:
            return mid
        if flo * fm < 0:
            hi, fhi = mid, fm
        else:
            lo, flo = mid, fm
    return (lo + hi) / 2


# ---------------------------------------------------------------- 1. tornado
def tornado(pool) -> list[dict]:
    base = gap({})
    jobs, keys = [], []
    for key, p in PARAMS.items():
        for mult in (1 - BAND, 1 + BAND):
            v = p['base'] * mult if key != 'ai.tooling' else mult
            jobs.append(({key: v}, SEED_BLOCKS[0], RUNS))
            keys.append((key, mult, v))
    res = pool.map(_task, jobs)
    out = {}
    for (key, mult, v), r in zip(keys, res):
        out.setdefault(key, {})['low' if mult < 1 else 'high'] = dict(value=v, **{k: r[k] for k in (
            'win_fraction', 'win_ci95', 'mean_cash_diff', 'mean_cash_diff_ci95', 'mean_incidents_slot0')})
    rows = []
    for key, d in out.items():
        swing = abs(d['high']['mean_cash_diff'] - d['low']['mean_cash_diff'])
        rows.append(dict(param=key, label=PARAMS[key]['label'], group=PARAMS[key]['group'],
                         baseline=PARAMS[key]['base'], swing_gbp=swing,
                         flips_winner=(d['low']['mean_cash_diff'] > 0) != (d['high']['mean_cash_diff'] > 0)
                                      or (d['low']['mean_cash_diff'] > 0) != (base['mean_cash_diff'] > 0)
                                      or (d['high']['mean_cash_diff'] > 0) != (base['mean_cash_diff'] > 0),
                         **d))
    rows.sort(key=lambda r: -r['swing_gbp'])
    return {'baseline': {k: base[k] for k in ('win_fraction', 'win_ci95', 'mean_cash_diff', 'mean_cash_diff_ci95')},
            'band': BAND, 'runs': RUNS, 'rows': rows}


# ---------------------------------------------------------------- 2. tipping points
TIP_RANGE = {  # search interval as multiples of the baseline value
    'ai.capacity': (0.7, 1.6), 'ai.defect_factor': (0.5, 1.6), 'ai.review_strength': (0.5, 1.6),
    'ai.monthly_staff_cost': (0.5, 1.4), 'ai.tooling': (0.2, 2.5),
    'trad.capacity': (0.7, 1.6), 'trad.defect_factor': (0.5, 1.6), 'trad.review_strength': (0.5, 1.2),
    'trad.monthly_staff_cost': (0.6, 1.4),
    'shared.debt_per_build': (0.4, 2.0), 'shared.review_effect': (0.2, 2.0), 'shared.debt_threshold': (0.7, 3.0),
    'shared.churn_base': (0.2, 4.0), 'shared.arpu': (0.5, 2.0), 'shared.cost_per_customer': (0.2, 5.0),
    'shared.overhead': (0.2, 3.0),
}


def _tip_task(args):
    key, seed, runs = args
    lo_m, hi_m = TIP_RANGE[key]
    base = PARAMS[key]['base'] if key != 'ai.tooling' else 1.0
    f = lambda m: gap({key: (base * m) if key != 'ai.tooling' else m}, seed, runs)['mean_cash_diff']
    m = breakeven_bisect(f, lo_m, hi_m)
    return key, seed, m


def tipping_points(pool) -> list[dict]:
    jobs = [(k, s, RUNS) for k in PARAMS for s in SEED_BLOCKS]
    res = pool.map(_tip_task, jobs)
    by = {}
    for key, seed, m in res:
        by.setdefault(key, []).append(m)
    rows = []
    for key, ms in by.items():
        found = [m for m in ms if m is not None]
        base = PARAMS[key]['base']
        row = dict(param=key, label=PARAMS[key]['label'], group=PARAMS[key]['group'], baseline=base,
                   search_multiples=TIP_RANGE[key], blocks_found=len(found), blocks=len(ms))
        if found:
            mid = st.mean(found)
            row.update(tipping_multiple=round(mid, 3), tipping_multiple_min=round(min(found), 3),
                       tipping_multiple_max=round(max(found), 3),
                       tipping_value=round(mid * base, 4) if key != 'ai.tooling' else round(mid, 3),
                       change_from_baseline_pct=round((mid - 1) * 100, 1))
        else:
            row.update(tipping_multiple=None)
        rows.append(row)
    rows.sort(key=lambda r: abs(r['change_from_baseline_pct']) if r.get('tipping_multiple') else 1e9)
    return rows


# ---------------------------------------------------------------- 3. statistical vs parameter uncertainty
def seed_blocks() -> dict:
    """The same baseline model, fresh random draws. This is statistical uncertainty on its own."""
    rows = []
    for s in SEED_BLOCKS + [40_042, 50_042]:
        r = gap({}, s, RUNS)
        rows.append({'seed_start': s, 'win_fraction': r['win_fraction'], 'mean_cash_diff': r['mean_cash_diff']})
    wins = [r['win_fraction'] for r in rows]
    diffs = [r['mean_cash_diff'] for r in rows]
    return {'blocks': rows, 'win_min': min(wins), 'win_max': max(wins), 'gap_min': min(diffs), 'gap_max': max(diffs)}


# ---------------------------------------------------------------- 4. global sample over every assumption
def _draw_task(args):
    over, seed, runs = args
    r = gap(over, seed, runs)
    return r['mean_cash_diff'], r['win_fraction']


def global_sample(pool, draws: int = 400, runs: int = 150, spread: float = 0.30, seed: int = 11) -> dict:
    rng = random.Random(seed)
    keys = list(PARAMS)
    samples = []
    for _ in range(draws):
        over = {}
        for k in keys:
            m = rng.uniform(1 - spread, 1 + spread)
            over[k] = m if k == 'ai.tooling' else PARAMS[k]['base'] * m
        # keep review strengths inside [0, 1]
        for k in ('ai.review_strength', 'trad.review_strength'):
            over[k] = min(over[k], 1.0)
        samples.append(over)
    res = pool.map(_draw_task, [(o, SEED_BLOCKS[0], runs) for o in samples])
    diffs = [r[0] for r in res]
    wins = [r[1] for r in res]
    drivers = {k: round(spearman([s[k] for s in samples], diffs), 3) for k in keys}
    return {'draws': draws, 'runs_per_draw': runs, 'spread': spread,
            'fraction_of_draws_ai_heavy_ahead_on_mean_cash': round(sum(d > 0 for d in diffs) / draws, 3),
            'spearman_with_mean_cash_gap': dict(sorted(drivers.items(), key=lambda kv: -abs(kv[1])))}


# ---------------------------------------------------------------- 5. checks on the model's structure
def structure_checks() -> dict:
    out = {}
    # Does more capacity automatically create more value? Sweep to far beyond the baseline.
    cap = {}
    for label, extra in (('baseline_quality', {}), ('good_quality', {'ai.defect_factor': 1.0, 'ai.review_strength': 0.8})):
        rows = []
        for c in (100, 135, 170, 220, 300, 400):
            models, a = build({'ai.capacity': c, **extra})
            r = paired(models, BASE, runs=RUNS, assumptions=a)
            f_prod = []
            for i in range(300):
                firms, _ = run_once(42 + i, 36, BASE, models=models, assumptions=a)
                f_prod.append(firms[0].product)
            rows.append({'capacity': c, 'win_fraction': r['win_fraction'], 'mean_cash_diff': r['mean_cash_diff'],
                         'mean_incidents_ai': r['mean_incidents_slot0'], 'mean_product_ai': round(st.mean(f_prod), 1)})
        cap[label] = rows
    out['capacity'] = cap
    # Do the debt thresholds decide the result? (they create the cliff)
    out['debt_threshold'] = [{'threshold': t, **{k: v for k, v in gap({'shared.debt_threshold': t}).items()
                                                  if k in ('win_fraction', 'mean_cash_diff', 'mean_incidents_slot0')}}
                             for t in (20, 28, 40, 60, 100)]
    # Decision speed.
    out['decision_cadence'] = []
    for c in (1, 2, 3, 6, 12):
        r = paired((replace(AI_NATIVE, decision_cadence=c), TRADITIONAL), BASE, runs=RUNS)
        out['decision_cadence'].append({'months': c, 'win_fraction': r['win_fraction'], 'mean_cash_diff': r['mean_cash_diff'],
                                        'mean_cash_diff_ci95': r['mean_cash_diff_ci95']})
    # Common costs cancel out of the cash gap unless a firm runs out of cash.
    out['common_overhead'] = [{'overhead': v, **{k: val for k, val in gap({'shared.overhead': v}).items()
                                                  if k in ('win_fraction', 'mean_cash_diff')}}
                              for v in (20_000, 35_000, 60_000, 90_000)]
    # Financial distress: how close does anyone come, and does a harsh market change the answer?
    stress = {
        'baseline': {},
        'market_downturn': dict(downturn_start=13, downturn_months=12, downturn_mult=0.5),
        'deep_downturn': dict(downturn_start=7, downturn_months=18, downturn_mult=0.3),
        'thin_cash_heavy_overhead': dict(start_cash=600_000, overhead=90_000),
        'thin_cash_heavy_overhead_and_downturn': dict(start_cash=600_000, overhead=90_000,
                                                      downturn_start=13, downturn_months=12, downturn_mult=0.5),
    }
    out['stress'] = {}
    for name, a_over in stress.items():
        a = replace(DEFAULT_ASSUMPTIONS, **a_over)
        wins = diffs = 0
        survive = [0, 0]
        mins = [[], []]
        d = []
        for i in range(RUNS):
            firms, _ = run_once(42 + i, 36, BASE, assumptions=a)
            g = firms[0].cash - firms[1].cash
            d.append(g)
            wins += g > 0
            for j in (0, 1):
                survive[j] += firms[j].alive
                mins[j].append(firms[j].min_cash)
        out['stress'][name] = {
            'win_fraction': round(wins / RUNS, 4), 'mean_cash_diff': round(st.mean(d)),
            'survival_ai_heavy': round(survive[0] / RUNS, 3), 'survival_traditional': round(survive[1] / RUNS, 3),
            'lowest_cash_ai_heavy': round(min(mins[0])), 'lowest_cash_traditional': round(min(mins[1])),
        }
    return out


def main():
    ap = argparse.ArgumentParser(description='Sensitivity analysis for the two-firm simulator')
    ap.add_argument('--output', type=Path, default=Path('results'))
    ap.add_argument('--procs', type=int, default=4)
    ap.add_argument('--skip-tipping', action='store_true')
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    with Pool(args.procs) as pool:
        result = {'model_version': MODEL_VERSION, 'runs_per_condition': RUNS, 'seed_blocks': SEED_BLOCKS}
        print('tornado ...', flush=True)
        result['tornado'] = tornado(pool)
        print('seed blocks ...', flush=True)
        result['statistical_uncertainty'] = seed_blocks()
        print('global sample ...', flush=True)
        result['global_sample'] = global_sample(pool)
        if not args.skip_tipping:
            print('tipping points ...', flush=True)
            result['tipping_points'] = tipping_points(pool)
        print('structure checks ...', flush=True)
        result['structure'] = structure_checks()
    (args.output / 'sensitivity.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(f'wrote {args.output / "sensitivity.json"}')


if __name__ == '__main__':
    main()
