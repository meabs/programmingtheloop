#!/usr/bin/env python3
"""Two rival digital firms, two operating models: illustrative Monte Carlo simulator.

Standard library only. No claim that configured parameters are empirical estimates.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import random
import statistics
from dataclasses import asdict, dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class Model:
    name: str
    capacity: float  # Work units/month after staffing and tooling
    monthly_staff_cost: float  # GBP
    ai_tool_cost: float  # GBP base recurring spend
    token_cost_per_work: float  # GBP for AI-delivered work
    defect_factor: float  # Relative debt introduced per build unit
    decision_cadence: int  # Months between reallocations
    review_strength: float  # Lower = cheaper, higher = stronger assurance


@dataclass(frozen=True)
class Scenario:
    name: str
    native_capacity_mult: float = 1.0
    native_defect_mult: float = 1.0
    native_tool_mult: float = 1.0
    native_review_delta: float = 0.0
    market_growth_mult: float = 1.0
    compliance_shocks: bool = True


TRADITIONAL = Model('Traditional', 100, 205_000, 6_000, 15, 1.0, 3, 0.80)
AI_NATIVE = Model('AI-native', 135, 150_000, 32_000, 200, 1.35, 1, 0.55)
SCENARIOS = {
    'baseline': Scenario('baseline'),
    'ai-friction': Scenario('ai-friction', native_capacity_mult=0.85, native_defect_mult=1.5, native_tool_mult=1.65),
    'ai-mature': Scenario('ai-mature', native_capacity_mult=1.12, native_defect_mult=0.75, native_review_delta=0.15),
    'slow-market': Scenario('slow-market', market_growth_mult=0.55),
}
INITIAL_ALLOCATION = {'discover': .16, 'build': .36, 'harden': .21, 'grow': .16, 'govern': .11}


@dataclass
class Firm:
    model: Model
    customers: float = 3_500
    cash: float = 2_500_000
    product: float = 49
    fit: float = 48
    debt: float = 18
    trust: float = 72
    governance: float = 66
    last_allocation: dict = field(default_factory=lambda: INITIAL_ALLOCATION.copy())
    incidents: int = 0
    bad_builds: int = 0
    cumulative_profit: float = 0
    delivered_work: float = 0
    alive: bool = True


def clamp(x: float, lo: float, hi: float) -> float:
    return min(max(x, lo), hi)


# Pure risk/penalty formulas, factored out so the JS port can be parity-tested on a grid of inputs
# (end-to-end runs rarely reach e.g. low-governance states). Arithmetic order is preserved exactly.
def debt_penalty(debt: float) -> float:
    return clamp(1 - max(0, debt - 20) * .0045, .40, 1.0)


def bad_build_probability(governance: float, fit: float, review: float, event: str) -> float:
    p = .008 + max(0, 60 - governance) * .0018 + \
        max(0, 55 - fit) * .0008 + (1 - review) * .027
    if event == 'compliance':
        p += .045
    return p


def incident_probability(debt: float, governance: float, event: str, bad_build: bool) -> float:
    risk = .012 + max(0, debt - 28) * .0022 + max(0, 55 - governance) * .0015
    if event == 'outage':
        risk += .13
    if bad_build:
        risk += .08
    return min(.45, risk)


def churn_rate(trust: float, debt: float, incident: bool) -> float:
    return clamp(.014 + max(0, 65 - trust) * .00048 +
                 max(0, debt - 28) * .00018 + (0.012 if incident else 0),
                 .004, .14)


def choose_allocation(firm: Firm, month: int, event: str, rng: random.Random) -> dict:
    if (month - 1) % firm.model.decision_cadence != 0:
        return firm.last_allocation.copy()
    # Same basic policy for both; only change frequency differs.
    allocation = INITIAL_ALLOCATION.copy()
    if event == 'new-demand':
        allocation.update(discover=.23, build=.43, harden=.15, grow=.12, govern=.07)
    elif event == 'compliance':
        allocation.update(discover=.09, build=.21, harden=.25, grow=.10, govern=.35)
    elif event == 'outage':
        allocation.update(discover=.08, build=.21, harden=.44, grow=.10, govern=.17)
    elif event == 'price-pressure':
        allocation.update(discover=.12, build=.33, harden=.20, grow=.25, govern=.10)
    # Same decision noise distribution for both models, not AI-specific magic.
    vals = {k: max(.025, v + rng.gauss(0, .015)) for k, v in allocation.items()}
    s = sum(vals.values())
    return {k: v / s for k, v in vals.items()}


def event_for_month(month: int, rng: random.Random, scenario: Scenario) -> str:
    # Shared market shocks. These are the same for both rival firms.
    # Keep event conditions independent of either firm's success.
    events = ['normal'] * 72 + ['new-demand'] * 9 + ['outage'] * 7 + ['price-pressure'] * 8
    if scenario.compliance_shocks:
        events += ['compliance'] * 4
    return rng.choice(events)


def apply_operations(firm: Firm, month: int, event: str, scenario: Scenario,
                     firm_random: random.Random) -> dict:
    if not firm.alive:
        return {'work': 0, 'incident': False, 'bad_build': False, 'cost': 0}
    native = firm.model.name == 'AI-native'
    allocation = choose_allocation(firm, month, event, firm_random)
    firm.last_allocation = allocation

    cap_mult = scenario.native_capacity_mult if native else 1.0
    defect_mult = scenario.native_defect_mult if native else 1.0
    review = clamp(firm.model.review_strength + (scenario.native_review_delta if native else 0), 0, 1)
    work = max(0, firm.model.capacity * cap_mult * debt_penalty(firm.debt) *
               clamp(firm_random.gauss(1, .065), .7, 1.3))
    units = {k: work * v for k, v in allocation.items()}
    firm.delivered_work += work

    # Technical work: discovery makes implementation more relevant; maintenance reduces debt.
    firm.fit = clamp(firm.fit + units['discover'] * .068 * (100 - firm.fit) / 60, 0, 100)
    build_value = units['build'] * (.047 + (firm.fit - 45) * .00028)
    if event == 'new-demand':
        build_value *= 1.30
    firm.product = clamp(firm.product + build_value * (100 - firm.product) / 65, 0, 100)

    # More output can mean more defects; hardening and governance counterbalance it.
    review_modifier = 1.15 - .40 * review
    new_debt = units['build'] * .068 * firm.model.defect_factor * defect_mult * review_modifier
    firm.debt = clamp(firm.debt + new_debt - units['harden'] * .105, 0, 100)
    firm.governance = clamp(firm.governance + units['govern'] * .078 - units['build'] * .017, 0, 100)

    # Bad build: knowingly violating a required control despite pressure to deliver.
    bad_build = firm_random.random() < bad_build_probability(firm.governance, firm.fit, review, event)
    if bad_build:
        firm.bad_builds += 1
        firm.debt = clamp(firm.debt + 5, 0, 100)
        firm.trust = clamp(firm.trust - 3, 0, 100)

    # Incident risk is a function of actual debt and governance, not a company label.
    incident = firm_random.random() < incident_probability(firm.debt, firm.governance, event, bad_build)
    if incident:
        firm.incidents += 1
        firm.trust = clamp(firm.trust - firm_random.uniform(4, 10), 0, 100)
        firm.debt = clamp(firm.debt + firm_random.uniform(1, 4), 0, 100)
    else:
        firm.trust = clamp(firm.trust + units['harden'] * .017 + units['govern'] * .012, 0, 100)

    # Business penalties and extra cost are caused by events + exposure, not brand of operating model.
    penalty = 0
    if event == 'compliance' and firm.governance < 65:
        penalty = (65 - firm.governance) * 3_500
        firm.trust = clamp(firm.trust - 2.0, 0, 100)
    if bad_build:
        penalty += 30_000
    if incident:
        penalty += firm_random.uniform(25_000, 100_000)

    token_mult = scenario.native_tool_mult if native else 1.0
    operating_cost = (firm.model.monthly_staff_cost + 35_000 + firm.customers * 8 +
                      firm.model.ai_tool_cost * token_mult +
                      work * firm.model.token_cost_per_work * token_mult + penalty)
    return {'work': work, 'incident': incident, 'bad_build': bad_build,
            'cost': operating_cost, 'growth_spend': units['grow'],
            'product': firm.product, 'fit': firm.fit}


def attractiveness(firm: Firm, growth_spend: float) -> float:
    if not firm.alive:
        return 0
    return (.39 * firm.product + .19 * firm.fit + .23 * firm.trust +
            .14 * (100 - firm.debt) + .05 * clamp(growth_spend * 2.5, 0, 100))


def run_once(seed: int, months: int, scenario: Scenario, keep_history: bool = False,
             models: tuple[Model, Model] | None = None):
    """Run one paired simulation. `models` overrides (slot0, slot1); default is (AI-native, Traditional)."""
    market_rng = random.Random(seed)
    rngs = [random.Random(seed * 73 + 11), random.Random(seed * 73 + 29)]
    m0, m1 = models if models is not None else (AI_NATIVE, TRADITIONAL)
    firms = [Firm(m0), Firm(m1)]
    history = []
    for month in range(1, months + 1):
        event = event_for_month(month, market_rng, scenario)
        # Every company receives the same market event and demand draw.
        market_demand = max(0, market_rng.gauss(480, 125)) * scenario.market_growth_mult
        if event == 'new-demand':
            market_demand *= 1.4
        if event == 'price-pressure':
            market_demand *= .75
        ops = [apply_operations(f, month, event, scenario, rng)
               for f, rng in zip(firms, rngs)]
        scores = [attractiveness(f, x.get('growth_spend', 0)) for f, x in zip(firms, ops)]

        # Choice between two firms and the outside option, with smooth market-share effects.
        weights = [math.exp((s - 60) / 17) if f.alive else 0
                   for f, s in zip(firms, scores)]
        denominator = sum(weights) + 0.8  # Outside option
        new_customers = [market_demand * w / denominator for w in weights]

        # Calculate churn from a pre-transfer snapshot, then apply switching simultaneously.
        churn_lost = []
        for i, f in enumerate(firms):
            if not f.alive:
                churn_lost.append(0.0)
                continue
            incident = ops[i]['incident']
            churn_lost.append(f.customers * churn_rate(f.trust, f.debt, incident))
        switched = [churn_lost[1] * .20 if firms[0].alive else 0,
                    churn_lost[0] * .20 if firms[1].alive else 0]

        for i, f in enumerate(firms):
            if not f.alive:
                # Keep bankrupt firms in the trace (frozen state, zero flows) instead of silently dropping them.
                if keep_history:
                    history.append(_row(seed, month, scenario, event, f, 0.0, 0.0, 0.0, 0.0))
                continue
            f.customers = max(0, f.customers - churn_lost[i] + new_customers[i] + switched[i])
            revenue = f.customers * 82  # GBP/customer/month
            profit = revenue - ops[i]['cost']
            f.cash += profit
            f.cumulative_profit += profit
            if f.cash <= 0:
                f.cash = 0
                f.alive = False
            if keep_history:
                history.append(_row(seed, month, scenario, event, f, profit, revenue,
                                    ops[i]['cost'], ops[i]['work']))
    return firms, history


def _row(seed, month, scenario, event, f: Firm, profit, revenue, cost, work) -> dict:
    return {
        'seed': seed, 'month': month, 'scenario': scenario.name, 'event': event,
        'company': f.model.name, 'customers': round(f.customers),
        'cash_gbp': round(f.cash), 'monthly_profit_gbp': round(profit),
        'revenue_gbp': round(revenue), 'cost_gbp': round(cost),
        'product': round(f.product, 2), 'fit': round(f.fit, 2),
        'debt': round(f.debt, 2), 'trust': round(f.trust, 2),
        'governance': round(f.governance, 2), 'work': round(work, 1),
        'incidents_cumulative': f.incidents, 'bad_builds_cumulative': f.bad_builds,
        'alive': f.alive,
    }


def monte_carlo(runs: int, months: int, scenario: Scenario, seed: int = 42,
                models: tuple[Model, Model] | None = None) -> dict:
    rows = []
    for i in range(runs):
        firms, _ = run_once(seed + i, months, scenario, models=models)
        rows.append({
            'native_cash': firms[0].cash, 'traditional_cash': firms[1].cash,
            'native_customers': firms[0].customers, 'traditional_customers': firms[1].customers,
            'native_incidents': firms[0].incidents, 'traditional_incidents': firms[1].incidents,
            'native_bad_builds': firms[0].bad_builds, 'traditional_bad_builds': firms[1].bad_builds,
            'native_survives': int(firms[0].alive), 'traditional_survives': int(firms[1].alive),
            'native_work': firms[0].delivered_work, 'traditional_work': firms[1].delivered_work,
        })
    # All output is descriptive under specified assumptions, NOT estimated real-world likelihood.
    cash_wins = sum(r['native_cash'] > r['traditional_cash'] for r in rows)
    equal = sum(r['native_cash'] == r['traditional_cash'] for r in rows)
    summary = {
        'scenario': scenario.name, 'runs': runs, 'months': months, 'seed_start': seed,
        'assumed_parameters': {
            'ai_native': asdict(AI_NATIVE), 'traditional': asdict(TRADITIONAL),
            'scenario': asdict(scenario),
        },
        'ai_native_cash_win_fraction': round(cash_wins / runs, 3),
        'cash_ties': equal,
        'median_final_cash_gbp': {
            'AI-native': round(statistics.median(r['native_cash'] for r in rows)),
            'Traditional': round(statistics.median(r['traditional_cash'] for r in rows)),
        },
        'median_customers': {
            'AI-native': round(statistics.median(r['native_customers'] for r in rows)),
            'Traditional': round(statistics.median(r['traditional_customers'] for r in rows)),
        },
        'mean_incidents': {
            'AI-native': round(statistics.mean(r['native_incidents'] for r in rows), 2),
            'Traditional': round(statistics.mean(r['traditional_incidents'] for r in rows), 2),
        },
        'mean_bad_builds': {
            'AI-native': round(statistics.mean(r['native_bad_builds'] for r in rows), 2),
            'Traditional': round(statistics.mean(r['traditional_bad_builds'] for r in rows), 2),
        },
        'survival_fraction': {
            'AI-native': round(statistics.mean(r['native_survives'] for r in rows), 3),
            'Traditional': round(statistics.mean(r['traditional_survives'] for r in rows), 3),
        },
        'median_work_units': {
            'AI-native': round(statistics.median(r['native_work'] for r in rows)),
            'Traditional': round(statistics.median(r['traditional_work'] for r in rows)),
        },
    }
    return summary


def main():
    parser = argparse.ArgumentParser(description='Competing digital companies simulator (illustrative assumptions)')
    parser.add_argument('--scenario', choices=tuple(SCENARIOS) + ('all',), default='all')
    parser.add_argument('--runs', type=int, default=200)
    parser.add_argument('--months', type=int, default=36)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--output', type=Path, default=Path('results'))
    args = parser.parse_args()
    if args.runs < 1 or args.months < 1:
        parser.error('--runs and --months must be >= 1')
    args.output.mkdir(parents=True, exist_ok=True)
    chosen = SCENARIOS.values() if args.scenario == 'all' else [SCENARIOS[args.scenario]]
    summaries = []
    for scenario in chosen:
        summary = monte_carlo(args.runs, args.months, scenario, args.seed)
        summaries.append(summary)
        print(f"{scenario.name:13} AI-native cash win fraction={summary['ai_native_cash_win_fraction']:.1%} "
              f"median cash AI/trad=£{summary['median_final_cash_gbp']['AI-native']:,}/"
              f"£{summary['median_final_cash_gbp']['Traditional']:,} "
              f"median customers AI/trad={summary['median_customers']['AI-native']:,}/"
              f"{summary['median_customers']['Traditional']:,}")
        # Detailed monthly trace for exactly one reproducible run per scenario.
        _, history = run_once(args.seed, args.months, scenario, keep_history=True)
        out_csv = args.output / f'{scenario.name}_single_run.csv'
        with out_csv.open('w', newline='', encoding='utf-8') as f:
            writer = csv.DictWriter(f, fieldnames=history[0].keys())
            writer.writeheader()
            writer.writerows(history)
    (args.output / 'summary.json').write_text(json.dumps(summaries, indent=2), encoding='utf-8')
    print(f'Wrote results to {args.output.resolve()}')


if __name__ == '__main__':
    main()
