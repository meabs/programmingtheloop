# Assumptions (model v0.2)

All of these are **invented**. None is calibrated to data and none is backed by evidence; they are illustrative, not estimates of AI productivity, software quality or anyone's costs. This file mirrors the table in the article, and a test in the website's repository checks the article's table against `web/sim.js`, which `web/test_parity.mjs` checks against `simulation.py`.

The first firm is called "AI-native" in the code and "AI-heavy" in the article.

The first table is the pair of firms. These are the assumptions that make one firm "AI-heavy".

| Parameter | Traditional | AI-heavy | Why it exists | Status |
|---|---|---|---|---|
| Delivery capacity (units of work a month) | 100 | 135 | The output a team can build before debt slows it. The 35% gap is my stand-in for "AI productivity". | Invented |
| Monthly staff cost | £205k | £150k | What the engineering team costs. | Invented |
| Monthly tooling | £6k | £32k | Fixed spend on AI tools and platforms. | Invented |
| Token cost per work unit | £15 | £200 | Usage-based AI cost for each unit delivered. | Invented |
| Defect factor | 1.0 | 1.35 | Technical debt created per unit of build work, relative to the traditional firm. | Invented |
| Review strength | 0.80 | 0.55 | Quality assurance before shipping. Higher means less debt created and fewer bad builds. | Invented |
| Decision cadence | quarterly (3 months) | monthly (1 month) | How often the firm re-plans how it splits its effort. | Invented |

The second table is what both firms share. These matter too, because they decide what the first table is worth.

| Parameter | Value (both firms) | Why it exists | Status |
|---|---|---|---|
| Starting position | £2.5m cash, 3,500 customers, product 49, fit 48, debt 18, trust 72, governance 66 | So the only differences are the assumptions above. | Invented |
| Revenue per customer | £82 a month | Turns customers into cash. | Invented |
| Running cost per customer | £8 a month | Support and hosting, so growth isn't free. | Invented |
| Common overhead | £35k a month | Costs that don't depend on how the software is delivered. | Invented |
| Technical debt per unit of build work | 0.068 | How fast building adds debt before the firm's defect factor and review apply. | Invented |
| How much review cuts that debt | 0.40 | Debt per build is multiplied by 1.15 − 0.40 × review strength. | Invented |
| Debt slows delivery above | 20 | Debt has a cost to output before it causes incidents. | Invented |
| Debt raises incident risk and churn above | 28 | A threshold I chose. It creates the cliff that decides much of the answer. | Invented |
| Base monthly churn | 1.4% | Customers leave even when nothing is wrong. | Invented |
| Share of churned customers who switch to the rival | 20% | So the firms interact a little. | Invented |
| Horizon | 36 months | Long enough for debt to matter. | Invented |

Every other constant, from the incident probabilities to the market's event mix, is in the box below. There are a lot of them, which is rather the point.

### Every other constant in the model

| Constant | Value | Role |
|---|---|---|
| Monthly delivery noise | ±6.5% (normal), clamped to 0.7 to 1.3 times | So no month is exactly average. |
| Delivery slowdown from debt | −0.45% per debt point above 20, floor 40% of capacity | The cost of debt to output. |
| Effort split (both firms), in the order discover / build / harden / grow / govern | 16 / 36 / 21 / 16 / 11 percent, nudged by the month's event, noise ±1.5 points | The same policy for both, so strategy isn't a hidden variable. |
| Split in a new-demand month | 23 / 43 / 15 / 12 / 7 | Build more when demand spikes. |
| Split in a compliance month | 9 / 21 / 25 / 10 / 35 | Govern more. |
| Split in an outage month | 8 / 21 / 44 / 10 / 17 | Harden more. |
| Split under price pressure | 12 / 33 / 20 / 25 / 10 | Grow more. |
| Product-market fit gain | 0.068 per discover unit, with diminishing headroom | Discovery makes building more relevant. |
| Product gain per build unit | 0.047 plus 0.00028 per fit point above 45, ×1.30 in a new-demand month, with diminishing headroom | What building is worth. |
| Debt removed by hardening | 0.105 per unit | Maintenance pays the debt down. |
| Governance | +0.078 per govern unit, −0.017 per build unit | Building fast erodes controls. |
| Bad build probability | 0.8% + 0.18 points per governance point below 60 + 0.08 points per fit point below 55 + 2.7% × (1 − review); +4.5 points in a compliance month | Knowingly breaking a control under pressure. |
| Bad build consequence | debt +5, trust −3, £30k | |
| Incident probability | 1.2% + 0.22 points per debt point above 28 + 0.15 points per governance point below 55; +13 points in an outage month; +8 points after a bad build; capped at 45% | Incidents come from state, not from a label. |
| Incident consequence | trust −4 to −10, debt +1 to +4, £25k to £100k | |
| Quiet-month trust gain | +0.017 per harden unit, +0.012 per govern unit | |
| Compliance penalty | £3.5k per governance point below 65 in a compliance month, trust −2 | |
| Churn | 1.4% + 0.048 points per trust point below 65 + 0.018 points per debt point above 28 + 1.2 points after an incident, clamped to 0.4% to 14% | |
| Market demand | about 480 new prospects a month (normal, spread 125) | Shared by both firms. |
| Event mix, per 100 months | 72 normal, 9 new-demand (demand ×1.4), 7 outage, 8 price pressure (demand ×0.75), 4 compliance | Independent month to month. |
| How prospects choose | share of demand set by attractiveness (0.39 product, 0.19 fit, 0.23 trust, 0.14 × (100 − debt), 0.05 growth spend), a softmax with scale 17, centre 60 and an outside option of 0.8 | |

Status of every row: invented.
