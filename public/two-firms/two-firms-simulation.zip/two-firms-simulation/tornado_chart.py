#!/usr/bin/env python3
"""Draw the tornado chart from results/sensitivity.json as a standalone SVG (standard library only).

Usage: python3 tornado_chart.py [results/sensitivity.json] [results/tornado.svg]
"""
from __future__ import annotations

import json
import sys
from html import escape
from pathlib import Path

COLOURS = {'AI-heavy': '#1f6f8b', 'Traditional': '#b4532a', 'Shared': '#898781'}
INK, MUTED, GRID = '#1d2a44', '#4a5873', '#d9d4c6'


def money(v: float) -> str:
    sign = '−' if v < 0 else '+' if v > 0 else ''
    return f"{sign}£{abs(v) / 1e3:.0f}k" if 0 < abs(v) < 5e5 else f"{sign}£{abs(v) / 1e6:.1f}m"


def draw(data: dict) -> str:
    rows = data['tornado']['rows']
    base = data['tornado']['baseline']['mean_cash_diff']
    lo = min(min(r['low']['mean_cash_diff'], r['high']['mean_cash_diff']) for r in rows)
    hi = max(max(r['low']['mean_cash_diff'], r['high']['mean_cash_diff']) for r in rows)
    lo, hi = (int(lo // 5e5) - 0) * 5e5, (int(hi // 5e5) + 1) * 5e5
    x0, x1 = 640, 1720
    X = lambda v: x0 + (v - lo) / (hi - lo) * (x1 - x0)  # noqa: E731
    top, rh = 190, 46
    H = top + rh * len(rows) + 215
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="1800" height="{H}" viewBox="0 0 1800 {H}" '
         f'font-family="Inter, Helvetica, Arial, sans-serif">',
         f'<rect width="1800" height="{H}" fill="#ffffff"/>',
         f'<text x="40" y="62" font-size="40" font-weight="700" fill="{INK}">Which assumptions decide the winner?</text>',
         f'<text x="40" y="102" font-size="25" fill="{MUTED}">Average final cash gap, AI-heavy minus traditional, when one assumption at a time is moved to 80% and 120% of its baseline value.</text>']
    # legend
    lx = 40
    for g, c in COLOURS.items():
        o.append(f'<rect x="{lx}" y="128" width="22" height="22" rx="4" fill="{c}"/>'
                 f'<text x="{lx + 32}" y="147" font-size="24" fill="{INK}">{escape(g)}</text>')
        lx += 40 + 14 * len(g) + 30
    # axis grid
    t = lo
    while t <= hi + 1:
        o.append(f'<line x1="{X(t):.1f}" x2="{X(t):.1f}" y1="{top - 14}" y2="{top + rh * len(rows)}" stroke="{GRID}" stroke-width="{3 if t == 0 else 1}"/>')
        o.append(f'<text x="{X(t):.1f}" y="{top + rh * len(rows) + 30}" font-size="22" fill="{MUTED}" text-anchor="middle">{"0" if t == 0 else money(t)}</text>')
        t += 5e5
    o.append(f'<text x="{X(0) + 8:.1f}" y="{top - 22}" font-size="22" fill="{INK}" font-weight="600">AI-heavy ahead →</text>')
    o.append(f'<text x="{X(0) - 8:.1f}" y="{top - 22}" font-size="22" fill="{INK}" font-weight="600" text-anchor="end">← traditional ahead</text>')
    # baseline marker
    o.append(f'<line x1="{X(base):.1f}" x2="{X(base):.1f}" y1="{top - 8}" y2="{top + rh * len(rows)}" stroke="{INK}" stroke-width="2" stroke-dasharray="6 5"/>')
    for i, r in enumerate(rows):
        y = top + i * rh
        a, b = r['low'], r['high']
        va, vb = a['mean_cash_diff'], b['mean_cash_diff']
        c = COLOURS[r['group']]
        left, right = (a, b) if va <= vb else (b, a)
        pct = lambda d: '−20%' if d is a else '+20%'  # noqa: E731
        o.append(f'<text x="40" y="{y + 30}" font-size="25" fill="{INK}">{escape(r["label"])}</text>')
        o.append(f'<rect x="{X(min(va, vb)):.1f}" y="{y + 8}" width="{max(2.0, X(max(va, vb)) - X(min(va, vb))):.1f}" height="30" rx="4" fill="{c}"/>')
        o.append(f'<text x="{X(left["mean_cash_diff"]) - 8:.1f}" y="{y + 30}" font-size="21" fill="{MUTED}" text-anchor="end">{pct(left)}</text>')
        o.append(f'<text x="{X(right["mean_cash_diff"]) + 8:.1f}" y="{y + 30}" font-size="21" fill="{MUTED}">{pct(right)}</text>')
    ny = top + rh * len(rows) + 62
    o.append(f'<rect x="40" y="{ny}" width="1720" height="92" rx="14" fill="#f3efe6" stroke="#b9b2a0" stroke-width="3"/>')
    o.append(f'<text x="70" y="{ny + 38}" font-size="25" fill="{INK}">Dashed line: the baseline gap ({money(base)}, ±£{data["tornado"]["baseline"]["mean_cash_diff_ci95"] / 1e3:.0f}k from random variation). A bar that crosses zero is an assumption that can</text>')
    o.append(f'<text x="70" y="{ny + 72}" font-size="25" fill="{INK}">change the winner. Common overhead is a single line: both firms pay it, so it cancels out. Invented coefficients throughout.</text>')
    o.append(f'<text x="1760" y="{H - 22}" font-size="21" fill="{MUTED}" text-anchor="end">Source: two-firms-simulation, model v0.2, sensitivity.py ({data["runs_per_condition"]:,} paired runs per bar end, seeds 42 onwards)</text>')
    o.append('</svg>')
    return '\n'.join(o)


if __name__ == '__main__':
    src = Path(sys.argv[1] if len(sys.argv) > 1 else 'results/sensitivity.json')
    out = Path(sys.argv[2] if len(sys.argv) > 2 else 'results/tornado.svg')
    out.write_text(draw(json.loads(src.read_text())), encoding='utf-8')
    print(f'wrote {out}')
