# Two companies: AI-heavy vs traditional software delivery

> **Naming.** The code, the CSVs and `results/` call the first firm "AI-native" (the name the original model used, kept so the original results stay byte-identical). In the article and on the interactive page it is called **AI-heavy**, because the model compares two ways of *delivering software*. It does not model a company that is AI-native in how it is run.

A reproducible, standard-library-only Python **illustrative** Monte Carlo simulation. Two rival digital subscription firms begin with equal cash, customers, product maturity and market access, then compete for new customers while experiencing the same market events.

## Run

```bash
python3 simulation.py --scenario all --runs 200 --months 36 --seed 42 --output results
```

It generates:
- `results/summary.json`: scenario-level results, survival, incidents, bad builds, customers and work delivered.
- `results/<scenario>_single_run.csv`: month-by-month, per-company traces for a single reproducible run.

## What actually differs?

- **Traditional**: lower effective work throughput, quarterly strategy adjustments, higher assumed staff cost, stronger default review practices.
- **AI-native**: higher effective throughput and monthly strategy adjustments, lower assumed staff cost, greater tool costs and greater debt introduced per work unit, with weaker default review practices.
- Both competitors use the **same** strategic allocation logic, initially equal product/market status, and receive the **same** external event each month.
- The business model includes customers, ARPU (£82/month), operating expense, churn, switching, product quality, product-market fit, technical debt, governance, trust, incidents, bad builds and market growth.

### Scenarios

| Scenario | Illustrative pressure applied to the AI-native company |
|---|---|
| `baseline` | Original assumptions |
| `ai-friction` | Lower productivity advantage; higher defects and tooling expense |
| `ai-mature` | Better productivity, reduced defects, stronger review |
| `slow-market` | Reduced customer-market growth for both |

## Model versions

| Version | What it is |
|---|---|
| v0.1 | The original model. Every coefficient was a literal in the code. `results/summary.json`, the four `results/*_single_run.csv` files and `results/experiment.json` are its output and are kept as the reference. |
| v0.2 | The same model with the shared coefficients lifted into `Assumptions` (defaults = the v0.1 values), the lowest cash each firm reaches recorded as `min_cash`, an optional demand downturn, and the sensitivity analysis. With no overrides it reproduces v0.1 **bit for bit**: `python3 -m unittest` checks the four shipped scenarios against `results/summary.json`, and rerunning `experiment.py` gives a byte-identical `results/experiment.json`. |

If a future change alters any default, it becomes a new version with its own results next to these, not an edit.

Every assumption, with its value for each firm, why it exists and its status (all invented), is in `ASSUMPTIONS.md`.

## Caveats

**This is not a prediction or evidence that one operating model wins.** The numerical coefficients are explicitly invented for exploratory model design. They must be replaced, or assigned plausible uncertainty ranges, using measured agent-task performance, operational data, market data and defensible economic inputs. Output win percentages are frequencies *conditional on the simulation's assumptions*, not real-world probabilities.

The traditional organisation still uses a little AI tooling, deliberately. That isolates the effect of reorganising around AI rather than simply giving one firm all the technology.

Important limitations of v0:
- Rival churn-to-switch transfers are approximate: 20% of each firm's churned customers move to the rival, computed from a pre-transfer snapshot and applied simultaneously (an earlier README version said "sequentially", which did not match the code). The results are not an accounting-accurate market microsimulation.
- Agent archetypes are represented by **organisation-level characteristics**, not actual autonomous agents making independently traceable decisions.
- No explicit hiring, pricing, customer cohorts, financing, strategic pivoting, regulatory regime or actual engineering tasks.
- Bankruptcy happens when cash is exhausted, and there is no fundraising.

## Next experimental upgrade

Build a **decision/evidence layer** for each model: release an identical quarterly business brief and repo snapshot to two independently configured LLM organisations, ask for staffing, product, risk and investment choices in a machine-readable schema, and let this **independent deterministic simulator** score consequences. Start with a blinded task-based calibration set before trusting simulated business outcomes. Keep evaluation separate from agent-generated rationale and never let an LLM judge its own strategy.

## Experiments (v0.1)

```bash
python3 experiment.py --output results     # ~1 minute; writes results/experiment.json
```

Adds an A/A null test, paired-seed confidence intervals (2,000 runs per condition), a trait ablation, one-at-a-time sensitivity sweeps with break-even points, and a 400-draw global uncertainty sample with Spearman driver ranking. `simulation.py` gained an optional `models=` argument; defaults are unchanged and the v0 `results/` files reproduce byte-for-byte. Findings, caveats and review notes are in **`EXPERIMENT_REPORT.md`**.

## Sensitivity analysis (v0.2)

```bash
python3 sensitivity.py --output results      # about 10 minutes on 4 cores; writes results/sensitivity.json
python3 tornado_chart.py                      # writes results/tornado.svg
```

Keeps two kinds of uncertainty apart: **statistical** (fresh random draws; reported as 95% intervals and as the spread across independent seed blocks) and **parameter** (what happens when an assumption changes; reported as tornado ranges at 80% and 120% of each baseline value, tipping points, and rank correlations across random assumption sets). Every comparison uses paired random conditions and the same seeds throughout. The report's section 7 has the findings.

## Interactive page

`web/` holds a browser version (`index.html` + `sim.js`) that runs the same model client-side: grouped assumptions with defaults and resets, a comparison with the baseline that says when your changes reverse the result, a one-assumption sweep with the tipping point marked, and a histogram of outcomes. `sim.js` is verified against this Python code (`node web/test_parity.mjs`). See `web/README.md`.

## Verify

```bash
python3 -m unittest -v        # 21 tests, including the v0.1 byte-for-byte check
node web/test_parity.mjs      # sim.js against the Python simulator
```

### Controlled decision interface for v1

The **next version** should let each company's team submit a quarterly decision envelope, for example:

```json
{
  "quarter": 4,
  "product_bets": ["reduce onboarding drop-off"],
  "allocation": {
    "discover": 0.16,
    "build": 0.36,
    "harden": 0.21,
    "grow": 0.16,
    "govern": 0.11
  },
  "risk_accepted": ["delay dashboard redesign"],
  "evidence_refs": ["brief-4-metric-2", "repo-onboarding-contract"]
}
```

The simulator (not the agents) validates budgets and operational constraints, resolves event shocks, scores outcomes and writes a tamper-evident run trace. Test real tasks to calibrate role-specific capability before using the simulation to draw conclusions about organisational performance.
