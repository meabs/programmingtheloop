import json
import unittest
from dataclasses import replace
from pathlib import Path

from experiment import breakeven, paired, spearman
from sensitivity import PARAMS, breakeven_bisect, build
from simulation import (AI_NATIVE, DEFAULT_ASSUMPTIONS, MODEL_VERSION, SCENARIOS, TRADITIONAL, Assumptions,
                        monte_carlo, run_once)

BASE = SCENARIOS['baseline']


class SimulationTests(unittest.TestCase):
    def test_reproducible(self):
        a = monte_carlo(12, 12, BASE, 42)
        b = monte_carlo(12, 12, BASE, 42)
        self.assertEqual(a, b)

    def test_default_models_match_explicit_models(self):
        a = monte_carlo(12, 12, BASE, 42)
        b = monte_carlo(12, 12, BASE, 42, models=(AI_NATIVE, TRADITIONAL))
        self.assertEqual(a, b)

    def test_events_independent_of_firm_behaviour(self):
        """Shared shocks must not depend on either firm's parameters (the old test was tautological:
        `event` is one variable per month, so it could never differ between rows)."""
        def events(models):
            _, h = run_once(42, 36, BASE, True, models=models)
            by_month = {}
            for r in h:
                by_month.setdefault(r['month'], set()).add(r['event'])
            return [by_month[m] for m in sorted(by_month)]
        weird = replace(AI_NATIVE, capacity=400, defect_factor=3.0, review_strength=0.0)
        self.assertEqual(events((AI_NATIVE, TRADITIONAL)), events((weird, TRADITIONAL)))
        self.assertEqual(events((AI_NATIVE, TRADITIONAL)), events((TRADITIONAL, TRADITIONAL)))

    def test_state_bounds(self):
        for sc in SCENARIOS.values():
            firms, history = run_once(14, 36, sc, True)
            for f in firms:
                self.assertGreaterEqual(f.cash, 0)
                self.assertGreaterEqual(f.customers, 0)
                self.assertTrue(0 <= f.product <= 100)
                self.assertTrue(0 <= f.debt <= 100)
                self.assertTrue(0 <= f.governance <= 100)
                self.assertTrue(0 <= f.trust <= 100)
            self.assertTrue(all(row['customers'] >= 0 for row in history))

    def test_identical_firms_have_no_slot_bias(self):
        """A/A null: identical firms should each win about half the time (binomial 99.9% band)."""
        wins = sum(f[0].cash > f[1].cash for f, _ in
                   (run_once(1000 + i, 36, BASE, models=(TRADITIONAL, TRADITIONAL)) for i in range(800)))
        self.assertTrue(0.43 < wins / 800 < 0.57, wins / 800)

    def test_more_capacity_means_more_delivered_work(self):
        lo = run_once(7, 24, BASE, models=(replace(AI_NATIVE, capacity=100), TRADITIONAL))[0][0]
        hi = run_once(7, 24, BASE, models=(replace(AI_NATIVE, capacity=170), TRADITIONAL))[0][0]
        self.assertGreater(hi.delivered_work, lo.delivered_work)

    def test_bankruptcy_path_and_trace_keeps_dead_firms(self):
        """v0 never reached bankruptcy, so this path (and a trace bug on it) was untested."""
        doomed = replace(AI_NATIVE, monthly_staff_cost=2_000_000)
        months = 24
        firms, history = run_once(3, months, BASE, True, models=(doomed, TRADITIONAL))
        self.assertFalse(firms[0].alive)
        self.assertEqual(firms[0].cash, 0)
        self.assertEqual(len(history), 2 * months)  # both firms present every month
        dead_rows = [r for r in history if r['company'] == 'AI-native' and not r['alive']]
        self.assertTrue(dead_rows)
        self.assertTrue(all(r['cash_gbp'] == 0 for r in dead_rows))
        # The bankruptcy month carries that month's loss; every later row has zero flows.
        self.assertTrue(all(r['monthly_profit_gbp'] == 0 and r['revenue_gbp'] == 0 for r in dead_rows[1:]))

    def test_experiment_helpers(self):
        self.assertAlmostEqual(spearman([1, 2, 3, 4], [10, 20, 30, 40]), 1.0)
        self.assertAlmostEqual(spearman([1, 2, 3, 4], [4, 3, 2, 1]), -1.0)
        self.assertAlmostEqual(breakeven([(0, -10.0), (10, 10.0)]), 5.0)
        self.assertIsNone(breakeven([(0, 1.0), (10, 2.0)]))


class ModelV02Tests(unittest.TestCase):
    """v0.2 lifted the shared coefficients into `Assumptions`. None of that may change a v0.1 result."""

    def test_version(self):
        self.assertEqual(MODEL_VERSION, '0.2')

    def test_v01_results_are_reproduced_exactly(self):
        """The shipped v0.1 summary (all four scenarios, 200 runs, seed 42) must come out identical."""
        shipped = json.loads((Path(__file__).parent / 'results' / 'summary.json').read_text())
        self.assertEqual({e['scenario'] for e in shipped}, set(SCENARIOS))
        for entry in shipped:
            self.assertEqual(monte_carlo(200, 36, SCENARIOS[entry['scenario']], 42), entry)

    def test_explicit_default_assumptions_change_nothing(self):
        self.assertEqual(monte_carlo(12, 12, BASE, 42), monte_carlo(12, 12, BASE, 42, assumptions=Assumptions()))
        self.assertEqual(Assumptions(), DEFAULT_ASSUMPTIONS)

    def test_fixed_seeds_reproduce_paired_results(self):
        a = replace(DEFAULT_ASSUMPTIONS, debt_per_build=.09, churn_base=.02)
        first = paired((AI_NATIVE, TRADITIONAL), BASE, runs=60, assumptions=a)
        self.assertEqual(first, paired((AI_NATIVE, TRADITIONAL), BASE, runs=60, assumptions=a))
        self.assertNotEqual(first['mean_cash_diff'], paired((AI_NATIVE, TRADITIONAL), BASE, runs=60)['mean_cash_diff'])

    def test_common_overhead_cancels_out_of_the_cash_gap(self):
        """Both firms pay the same overhead, so it cannot change who is ahead unless a firm runs out of cash."""
        hi = replace(DEFAULT_ASSUMPTIONS, overhead=90_000)
        for seed in range(30):
            a, _ = run_once(seed, 36, BASE)
            b, _ = run_once(seed, 36, BASE, assumptions=hi)
            self.assertTrue(all(f.alive for f in a + b))
            self.assertAlmostEqual((a[0].cash - a[1].cash) / 1e6, (b[0].cash - b[1].cash) / 1e6, places=6)

    def test_later_debt_threshold_means_fewer_incidents(self):
        lax = replace(DEFAULT_ASSUMPTIONS, debt_threshold=60)
        base = sum(run_once(s, 36, BASE)[0][0].incidents for s in range(150))
        high = sum(run_once(s, 36, BASE, assumptions=lax)[0][0].incidents for s in range(150))
        self.assertLess(high, base)

    def test_more_debt_per_build_means_more_debt(self):
        hot = replace(DEFAULT_ASSUMPTIONS, debt_per_build=.12)
        self.assertGreater(run_once(3, 24, BASE, assumptions=hot)[0][0].debt, run_once(3, 24, BASE)[0][0].debt)

    def test_downturn_hits_both_firms_and_is_off_by_default(self):
        down = replace(DEFAULT_ASSUMPTIONS, downturn_start=13, downturn_months=12, downturn_mult=0.5)
        a, _ = run_once(9, 36, BASE)
        b, _ = run_once(9, 36, BASE, assumptions=down)
        self.assertLess(b[0].customers, a[0].customers)
        self.assertLess(b[1].customers, a[1].customers)
        self.assertEqual(DEFAULT_ASSUMPTIONS.downturn_months, 0)

    def test_lowest_cash_is_tracked(self):
        firms, _ = run_once(3, 36, BASE)
        for f in firms:
            self.assertTrue(0 <= f.min_cash <= f.cash)
        poor = replace(DEFAULT_ASSUMPTIONS, start_cash=50_000, overhead=150_000)
        firms, _ = run_once(3, 36, BASE, assumptions=poor)
        self.assertFalse(any(f.alive for f in firms))
        self.assertTrue(all(f.min_cash == 0 for f in firms))

    def test_build_maps_parameters_to_models_and_assumptions(self):
        (ai, trad), a = build({})
        self.assertEqual((ai, trad, a), (AI_NATIVE, TRADITIONAL, DEFAULT_ASSUMPTIONS))
        (ai, trad), a = build({'ai.tooling': 1.5, 'trad.capacity': 120, 'shared.arpu': 90})
        self.assertAlmostEqual(ai.ai_tool_cost, AI_NATIVE.ai_tool_cost * 1.5)
        self.assertAlmostEqual(ai.token_cost_per_work, AI_NATIVE.token_cost_per_work * 1.5)
        self.assertEqual((trad.capacity, a.arpu), (120, 90))
        self.assertEqual(ai.capacity, AI_NATIVE.capacity)

    def test_every_swept_parameter_exists_in_the_model(self):
        for key, p in PARAMS.items():
            build({key: p['base']})  # raises if a name is not a Model or Assumptions field

    def test_breakeven_bisect(self):
        self.assertAlmostEqual(breakeven_bisect(lambda x: x - 3, 0, 10, iters=20), 3, places=3)
        self.assertIsNone(breakeven_bisect(lambda x: x + 1, 0, 10))
        self.assertEqual(breakeven_bisect(lambda x: x, 0, 10), 0)

    def test_worse_defects_lower_the_ai_heavy_firms_cash(self):
        lo = paired(build({'ai.defect_factor': 1.0})[0], BASE, runs=120)['mean_cash_diff']
        hi = paired(build({'ai.defect_factor': 1.7})[0], BASE, runs=120)['mean_cash_diff']
        self.assertGreater(lo, hi)


if __name__ == '__main__':
    unittest.main()
