import unittest
from dataclasses import replace

from experiment import breakeven, spearman
from simulation import AI_NATIVE, SCENARIOS, TRADITIONAL, monte_carlo, run_once

BASE = SCENARIOS['baseline']


class SimulationTests(unittest.TestCase):
    def test_reproducible(self):
        a = monte_carlo(12, 12, BASE, 42)
        b = monte_carlo(12, 12, BASE, 42)
        self.assertEqual(a, b)

    def test_default_models_match_explicit_models(self):
        a = monte_carlo(12, 12, BASE, 42)
        b = monte_carlo(12, 12, BASE, 42, models=(AI_NATIVE, TRADITIONAL))
        self.assertEqual(a, b)

    def test_events_independent_of_firm_behaviour(self):
        """Shared shocks must not depend on either firm's parameters (the old test was tautological:
        `event` is one variable per month, so it could never differ between rows)."""
        def events(models):
            _, h = run_once(42, 36, BASE, True, models=models)
            by_month = {}
            for r in h:
                by_month.setdefault(r['month'], set()).add(r['event'])
            return [by_month[m] for m in sorted(by_month)]
        weird = replace(AI_NATIVE, capacity=400, defect_factor=3.0, review_strength=0.0)
        self.assertEqual(events((AI_NATIVE, TRADITIONAL)), events((weird, TRADITIONAL)))
        self.assertEqual(events((AI_NATIVE, TRADITIONAL)), events((TRADITIONAL, TRADITIONAL)))

    def test_state_bounds(self):
        for sc in SCENARIOS.values():
            firms, history = run_once(14, 36, sc, True)
            for f in firms:
                self.assertGreaterEqual(f.cash, 0)
                self.assertGreaterEqual(f.customers, 0)
                self.assertTrue(0 <= f.product <= 100)
                self.assertTrue(0 <= f.debt <= 100)
                self.assertTrue(0 <= f.governance <= 100)
                self.assertTrue(0 <= f.trust <= 100)
            self.assertTrue(all(row['customers'] >= 0 for row in history))

    def test_identical_firms_have_no_slot_bias(self):
        """A/A null: identical firms should each win about half the time (binomial 99.9% band)."""
        wins = sum(f[0].cash > f[1].cash for f, _ in
                   (run_once(1000 + i, 36, BASE, models=(TRADITIONAL, TRADITIONAL)) for i in range(800)))
        self.assertTrue(0.43 < wins / 800 < 0.57, wins / 800)

    def test_more_capacity_means_more_delivered_work(self):
        lo = run_once(7, 24, BASE, models=(replace(AI_NATIVE, capacity=100), TRADITIONAL))[0][0]
        hi = run_once(7, 24, BASE, models=(replace(AI_NATIVE, capacity=170), TRADITIONAL))[0][0]
        self.assertGreater(hi.delivered_work, lo.delivered_work)

    def test_bankruptcy_path_and_trace_keeps_dead_firms(self):
        """v0 never reached bankruptcy, so this path (and a trace bug on it) was untested."""
        doomed = replace(AI_NATIVE, monthly_staff_cost=2_000_000)
        months = 24
        firms, history = run_once(3, months, BASE, True, models=(doomed, TRADITIONAL))
        self.assertFalse(firms[0].alive)
        self.assertEqual(firms[0].cash, 0)
        self.assertEqual(len(history), 2 * months)  # both firms present every month
        dead_rows = [r for r in history if r['company'] == 'AI-native' and not r['alive']]
        self.assertTrue(dead_rows)
        self.assertTrue(all(r['cash_gbp'] == 0 for r in dead_rows))
        # The bankruptcy month carries that month's loss; every later row has zero flows.
        self.assertTrue(all(r['monthly_profit_gbp'] == 0 and r['revenue_gbp'] == 0 for r in dead_rows[1:]))

    def test_experiment_helpers(self):
        self.assertAlmostEqual(spearman([1, 2, 3, 4], [10, 20, 30, 40]), 1.0)
        self.assertAlmostEqual(spearman([1, 2, 3, 4], [4, 3, 2, 1]), -1.0)
        self.assertAlmostEqual(breakeven([(0, -10.0), (10, 10.0)]), 5.0)
        self.assertIsNone(breakeven([(0, 1.0), (10, 2.0)]))


if __name__ == '__main__':
    unittest.main()
