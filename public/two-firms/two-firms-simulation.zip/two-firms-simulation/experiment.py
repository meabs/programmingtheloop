#!/usr/bin/env python3
"""Experiment harness for the two-firm simulator (v0.1).

Adds what v0 lacked: a null (A/A) test, paired-seed confidence intervals, trait ablation,
one-at-a-time sensitivity sweeps with break-even points, and a global uncertainty sample
with rank-correlation driver analysis. Standard library only; common random numbers
(seed + i) are used across every parameter setting to reduce variance.

All findings are conditional on invented coefficients. See README caveats.
"""
from __future__ import annotations

import argparse
import json
import math
import random
import statistics as st
from dataclasses import replace
from pathlib import Path

from simulation import AI_NATIVE, SCENARIOS, TRADITIONAL, Model, run_once

BASE = SCENARIOS['baseline']


def paired(models, scenario=BASE, runs=2000, months=36, seed=42) -> dict:
    """Slot 0 vs slot 1 on identical seeds. diff = slot0 final cash - slot1 final cash."""
    diffs, wins = [], 0
    inc0 = inc1 = 0
    for i in range(runs):
        f, _ = run_once(seed + i, months, scenario, models=models)
        d = f[0].cash - f[1].cash
        diffs.append(d)
        wins += d > 0
        inc0 += f[0].incidents
        inc1 += f[1].incidents
    p = wins / runs
    return {
        'runs': runs,
        'win_fraction': round(p, 4),
        'win_ci95': round(1.96 * math.sqrt(p * (1 - p) / runs), 4),
        'mean_cash_diff': round(st.mean(diffs)),
        'mean_cash_diff_ci95': round(1.96 * st.stdev(diffs) / math.sqrt(runs)),
        'median_cash_diff': round(st.median(diffs)),
        'mean_incidents_slot0': round(inc0 / runs, 2),
        'mean_incidents_slot1': round(inc1 / runs, 2),
    }


def null_tests(runs: int) -> dict:
    """A/A: identical firms must win ~50% each. Detects slot/ordering bias in the engine."""
    return {
        'traditional_vs_traditional': paired((TRADITIONAL, TRADITIONAL), runs=runs),
        'ai_native_vs_ai_native': paired((AI_NATIVE, AI_NATIVE), runs=runs),
    }


# Traits that differ between the two models, grouped so each ablation moves one conceptual lever.
TRAIT_GROUPS = {
    'capacity': ['capacity'],
    'staff_cost': ['monthly_staff_cost'],
    'tooling_spend': ['ai_tool_cost', 'token_cost_per_work'],
    'defect_factor': ['defect_factor'],
    'review_strength': ['review_strength'],
    'decision_cadence': ['decision_cadence'],
}


def ablation(runs: int) -> dict:
    """Swap one trait group at a time. Answers: which AI-native difference actually matters?"""
    out = {}
    for name, fields in TRAIT_GROUPS.items():
        ai_gets_trad = replace(AI_NATIVE, **{f: getattr(TRADITIONAL, f) for f in fields})
        trad_gets_ai = replace(TRADITIONAL, **{f: getattr(AI_NATIVE, f) for f in fields})
        out[name] = {
            'ai_native_with_traditional_value': paired((ai_gets_trad, TRADITIONAL), runs=runs),
            'traditional_with_ai_native_value': paired((AI_NATIVE, trad_gets_ai), runs=runs),
        }
    return out


SWEEPS = {
    'capacity': [100, 110, 120, 135, 150, 170],
    'defect_factor': [0.7, 1.0, 1.35, 1.7, 2.0, 2.5],
    'review_strength': [0.3, 0.45, 0.55, 0.7, 0.8, 0.9],
    'token_cost_per_work': [50, 100, 200, 300, 400, 600],
    'ai_tool_cost': [10_000, 20_000, 32_000, 45_000, 60_000],
    'monthly_staff_cost': [100_000, 125_000, 150_000, 175_000, 205_000],
    'decision_cadence': [1, 2, 3, 6],
}


def breakeven(points: list[tuple[float, float]]) -> float | None:
    """Linear interpolation of the first sign change of mean cash diff."""
    for (x0, y0), (x1, y1) in zip(points, points[1:]):
        if y0 == 0:
            return x0
        if y0 * y1 < 0:
            return round(x0 + (x1 - x0) * (-y0) / (y1 - y0), 3)
    return None


def sweeps(runs: int) -> dict:
    out = {}
    for param, values in SWEEPS.items():
        rows = []
        for v in values:
            ai = replace(AI_NATIVE, **{param: v})
            r = paired((ai, TRADITIONAL), runs=runs)
            rows.append({'value': v, **{k: r[k] for k in
                         ('win_fraction', 'mean_cash_diff', 'mean_cash_diff_ci95', 'mean_incidents_slot0')}})
        out[param] = {
            'points': rows,
            'breakeven_value_for_equal_mean_cash': breakeven([(r['value'], r['mean_cash_diff']) for r in rows]),
        }
    return out


# Plausible-but-arbitrary uncertainty ranges for the AI-native firm. Choosing these ranges IS the
# assumption; the headline "fraction of parameter space" is only as good as they are.
RANGES = {
    'capacity': (100, 160),
    'defect_factor': (0.8, 1.8),
    'review_strength': (0.35, 0.85),
    'token_cost_per_work': (50, 350),
    'ai_tool_cost': (15_000, 50_000),
    'monthly_staff_cost': (120_000, 205_000),
}


def ranks(xs: list[float]) -> list[float]:
    order = sorted(range(len(xs)), key=lambda i: xs[i])
    r = [0.0] * len(xs)
    for rank, i in enumerate(order):
        r[i] = float(rank)
    return r


def spearman(x: list[float], y: list[float]) -> float:
    rx, ry = ranks(x), ranks(y)
    mx, my = st.mean(rx), st.mean(ry)
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    den = math.sqrt(sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry))
    return num / den if den else 0.0


def global_sample(draws: int, runs: int, seed: int = 7) -> dict:
    rng = random.Random(seed)
    samples = []
    for _ in range(draws):
        params = {k: rng.uniform(*r) for k, r in RANGES.items()}
        params['decision_cadence'] = rng.choice([1, 1, 2, 3])  # AI-native leans monthly
        ai = replace(AI_NATIVE, **params)
        r = paired((ai, TRADITIONAL), runs=runs)
        samples.append((params, r['mean_cash_diff'], r['win_fraction']))
    diffs = [s[1] for s in samples]
    wins = [s[2] for s in samples]
    drivers = {k: round(spearman([s[0][k] for s in samples], diffs), 3)
               for k in list(RANGES) + ['decision_cadence']}
    return {
        'draws': draws, 'runs_per_draw': runs, 'ranges': RANGES,
        'fraction_of_draws_ai_native_ahead_on_mean_cash': round(sum(d > 0 for d in diffs) / draws, 3),
        'fraction_of_draws_ai_native_wins_majority_of_runs': round(sum(w > 0.5 for w in wins) / draws, 3),
        'mean_cash_diff_percentiles_gbp': {
            f'p{p}': round(st.quantiles(diffs, n=100)[p - 1]) for p in (5, 25, 50, 75, 95)},
        'spearman_with_mean_cash_diff': dict(sorted(drivers.items(), key=lambda kv: -abs(kv[1]))),
    }


def main():
    ap = argparse.ArgumentParser(description='Experiment harness for the two-firm simulator')
    ap.add_argument('--runs', type=int, default=2000, help='paired runs per condition')
    ap.add_argument('--draws', type=int, default=400, help='global-sample parameter draws')
    ap.add_argument('--draw-runs', type=int, default=150, help='paired runs per global draw')
    ap.add_argument('--output', type=Path, default=Path('results'))
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    result = {
        'null_tests': null_tests(args.runs),
        'baseline_by_scenario': {n: paired((AI_NATIVE, TRADITIONAL), sc, args.runs)
                                 for n, sc in SCENARIOS.items()},
        'ablation_baseline': ablation(args.runs),
        'sweeps_baseline': sweeps(args.runs),
        'global_sample': global_sample(args.draws, args.draw_runs),
    }
    (args.output / 'experiment.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
