# Experiment report: AI-native vs traditional firm simulator (v0 → v0.1)

**Scope.** Review of `digital_companies_sim_v0`, enhancements, and a structured experiment on the simulator's behaviour. Everything below is conditional on the simulator's *invented* coefficients (as the v0 README itself says). Nothing here is evidence about real organisations; it characterises **the model**: how it behaves, what drives it, and how much to trust its outputs.

**Reproduce.** `python3 -m unittest -v` (8 tests) · `python3 simulation.py --scenario all --runs 200 --months 36 --seed 42 --output results` · `python3 experiment.py --output results` (~1 min). All numbers use common random numbers (paired seeds `42..42+n-1`), Python 3.14, standard library only.

---

## 1. Summary

1. **The v0 headline is a near coin-flip, and v0 could not show that.** At baseline the AI-native firm wins on final cash in **45.5% ± 2.2** of 2,000 paired runs (v0's 43% at n=200 carried a ±6.9-point interval). Mean cash gap is **−£144k ± £54k**, about 1.5% of ~£9M median final cash: detectable, but economically small.
2. **The two firms cost almost exactly the same.** Fixed monthly cost is £244.0k (AI-native) vs £247.5k (traditional). The "cheaper staff" story is almost entirely cancelled by tooling and token spend. Any AI-native edge must come from throughput.
3. **The outcome is decided by three levers, not by "AI-native vs traditional":** defect rate (with review strength), staff cost, and tooling spend. Decision cadence, the "monthly vs quarterly agility" trait, is worth **~£53k, indistinguishable from zero**.
4. **The baseline sits on a knife-edge.** Every swept parameter's break-even is within 2–16% of its assumed value (§4.3). The scenario spread (0% → 98% wins) mostly reflects how far each scenario bundle pushes those levers.
5. **A debt tipping point drives the dynamics.** The baseline AI-native firm crosses the incident threshold (debt > 28) in 100% of runs at a median of month 9, versus 4% for traditional; month-36 debt is 55 vs 10.5.
6. **Failure is unreachable in v0.** Survival is 100% everywhere, even with market growth cut to 5% of baseline, so the bankruptcy code path was never exercised (and had a latent trace bug, now fixed).

## 2. Method

| Experiment | Design | n |
|---|---|---|
| A/A null | Identical firms (Trad–Trad, AI–AI), baseline scenario. Expect ~50%. | 2,000 each |
| Scenario comparison | v0's four scenarios, paired seeds, normal-approx 95% CIs | 2,000 each |
| Ablation | Swap one trait group (capacity, staff cost, tooling spend, defect factor, review strength, cadence) between firms, in both directions | 2,000 × 12 |
| One-at-a-time sweeps | Vary one AI-native parameter, hold the rest at baseline; linear-interpolated break-even | 2,000 × 34 points |
| Global sample | 400 uniform draws of six AI-native parameters (+ cadence ∈ {1,1,2,3}); Spearman rank correlation with mean cash gap | 400 × 150 |

Metric: final cash, AI-native minus traditional, per paired seed. "Win" = positive gap.

## 3. Results

### 3.1 Null test: engine is not biased by slot

| Pairing | Slot-0 win rate | 95% CI | Mean gap (£) |
|---|---|---|---|
| Traditional vs Traditional | 49.3% | ±2.2 | +1k ± 42k |
| AI-native vs AI-native | 51.6% | ±2.2 | +54k ± 59k |

Identical firms split ~50/50 and gaps are indistinguishable from zero, so the sequential-update order, the separate RNG streams and the switching mechanic introduce no detectable favouritism. This is a necessary check for any claim about the *non*-identical case.

### 3.2 Scenarios with proper intervals

| Scenario | v0 win (n=200) | **Win (n=2000)** | Mean gap | AI incidents (mean) |
|---|---|---|---|---|
| baseline | 43.0% | **45.5% ± 2.2** | −£144k ± 54k | 1.67 (trad 0.79) |
| slow-market | 42.5% | **45.1% ± 2.2** | −£96k ± 35k | 1.67 |
| ai-friction | 0.0% | **0.1% ± 0.1** | −£4.74M ± 57k | 3.50 |
| ai-mature | 97.0% | **98.3% ± 0.6** | +£2.24M ± 44k | 0.85 |

v0 numbers are consistent with these but too imprecise to tell "slightly behind" from "even". Note the unequal framing: `ai-friction` and `ai-mature` each change 3–4 parameters at once, so their spread is a statement about the bundles, not about "AI maturity" as a single dimension.

### 3.3 Ablation: which difference matters?

Mean cash gap when the AI-native firm adopts the traditional firm's value for one trait (baseline gap = −£144k). The trait's contribution is the change from baseline.

| Trait group | AI-native given traditional value | Contribution of AI-native's value | Reading |
|---|---|---|---|
| Staff cost (£150k vs £205k) | −£2,124k | **+£1.98M** | largest asset |
| Capacity (135 vs 100) | −£985k | **+£0.84M** | second asset |
| Decision cadence (1 vs 3) | −£197k | **+£0.05M** (≈ noise, CI ±£55k) | no effect |
| Review strength (0.55 vs 0.80) | +£735k | **−£0.88M** | liability |
| Defect factor (1.35 vs 1.0) | +£1,433k | **−£1.58M** | largest liability |
| Tooling spend (£32k + £200/unit vs £6k + £15/unit) | +£1,626k | **−£1.77M** | liability |

Effects are **not additive** (the six contributions sum to about −£1.4M, not −£144k) because debt, incidents, trust and churn interact. Read them as ranked magnitudes, not a decomposition. The mirrored direction (giving the traditional firm the AI-native value) gives the same ranking.

### 3.4 Sensitivity sweeps and break-evens

Value at which mean cash gap = 0, other parameters at baseline:

| Parameter | Assumed | Break-even | Distance |
|---|---|---|---|
| Defect factor | 1.35 | **1.32** | −2% |
| Monthly staff cost | £150,000 | £145,993 | −3% |
| Capacity | 135 | 141.8 | +5% |
| Review strength | 0.55 | 0.59 | +7% |
| AI tool cost | £32,000 | £27,993 | −13% |
| Token cost / work unit | £200 | £168 | −16% |
| Decision cadence | 1 month | none (monotone worse, −£144k → −£308k at 6 months) | n/a |

Defect factor is the steepest: win rate runs **98% (0.7) → 93% (1.0) → 46% (1.35) → 5% (1.7) → 0.7% (2.0)**. Capacity is self-limiting: raising it from 100 to 170 lifts AI-native incidents from 1.40 to 1.95 because more build output generates more debt.

### 3.5 Global uncertainty sample

Across 400 draws of the AI-native parameters (ranges in `experiment.py:RANGES`):

- AI-native ahead on mean cash in **41.5%** of draws (wins a majority of runs in 42.0%).
- Gap percentiles: p5 −£3.48M · p25 −£1.71M · **median −£0.46M** · p75 +£0.96M · p95 +£2.43M.
- Spearman driver ranking: **defect factor −0.72**, staff cost −0.47, capacity +0.30, review strength +0.23, token cost −0.20, tool cost −0.20, cadence −0.06.

The "41.5% of parameter space" figure is only as meaningful as the ranges, which are my own plausible-looking guesses. The robust part is the **driver ranking**.

### 3.6 Mechanism check

500 baseline runs, month-36 means:

| Firm | Debt | Trust | Customers | Runs crossing debt > 28 | Median month |
|---|---|---|---|---|---|
| AI-native, defect 1.0 | 18.6 | 87.5 | 8,857 | 23% | 21 |
| **AI-native, defect 1.35 (baseline)** | **55.4** | 80.2 | 7,609 | **100%** | **9** |
| AI-native, defect 1.7 | 87.5 | 69.1 | 6,209 | 100% | 5 |
| Traditional | 10.5 | 83.2 | 8,450 | 4% | 21 |

Above debt 20 capacity is throttled; above debt 28 incident risk rises linearly; incidents hit trust and raise churn. That chain produces a threshold-and-feedback structure, so small changes in defect or review parameters flip outcomes sharply.

## 4. Code review findings

**Fixed in v0.1**

| # | Finding | Fix |
|---|---|---|
| 1 | `test_event_stream_shared_between_competitors` was **tautological**: `event` is a single per-month variable, so rows could never differ. | Replaced with a test that the event stream is identical under wildly different firm parameters. Mutation-checked: injecting coupling makes it fail. |
| 2 | Bankrupt firms were **silently dropped from the trace** (`continue` before the history append). Unreachable in shipped runs, so untested. | Dead firms stay in the trace with frozen state and zero flows; added a forced-bankruptcy test. |
| 3 | README said switching is "calculated sequentially"; the code uses a **pre-transfer snapshot applied simultaneously**. | README corrected. |
| 4 | `apply_operations(..., market_random, ...)` took an unused RNG argument. | Removed. |
| 5 | No null test; no CIs; tests only checked invariants. | A/A test, slot-bias unit test, capacity monotonicity test, helper tests; `experiment.py` reports CIs. |

All v0 outputs (`summary.json` and the four single-run CSVs) reproduce **byte-identically** after the changes (checked).

**Noted, not changed (would alter results or is a design choice)**

- **Timing inconsistency:** variable cost uses `firm.customers` *before* the month's update; revenue uses it *after*. Small, but it makes profit slightly optimistic for growing firms.
- **Scenario bundling and name-keyed logic:** scenario multipliers apply when `model.name == 'AI-native'`, a string compare. Renaming a model silently disables its scenario effects.
- **Win-fraction metric ignores magnitude and survival.** `ai-friction` and a near-tie both read as "AI loses". Report the gap distribution (this report does).
- **Single-run CSVs are Monte Carlo run 0 (seed 42):** one arbitrary draw, not a representative path.
- **Cadence consumes RNG draws only on decision months**, so cadence also changes the noise stream, not just reaction lag. Common random numbers keep the mean comparison fair, but it is not a clean isolation of "agility".
- **Firms are weakly coupled.** Only the share softmax and the 20% churn-to-rival transfer link them, so this is closer to two parallel businesses facing a shared market than a head-to-head fight. Untested here.

## 5. Limitations

- Coefficients are invented; the results characterise the model, not reality. The v0 README's caveat stands in full.
- Sweeps are one-at-a-time around a single point; the global sample covers only six AI-native parameters and ignores traditional-firm uncertainty, market parameters and structural uncertainty (e.g., the debt thresholds themselves).
- Normal-approximation CIs; no multiple-comparison correction across 34 sweep points.
- Findings on cadence are limited by what cadence does in this model (only lag and noise). It does not capture learning, pivoting, or coordination costs.

## 6. Recommendations for v1

1. **Calibrate the two parameters that decide the outcome**: defect factor (and its review-strength interaction) first, then staff-vs-tooling cost. Everything else is second-order.
2. **Replace hand-built scenario bundles with sampled priors** and report gap distributions and driver rankings (`experiment.py` is the template).
3. **Make failure reachable** (thinner margins, fundraising, fixed-cost shocks) so survival becomes an informative outcome.
4. **Give cadence real mechanics** (information lag, learning, coordination overhead) or drop it from the claims.
5. **Smooth or justify the debt thresholds (20/28);** they create the tipping behaviour that dominates results.
6. Fix the cost/revenue timing inconsistency and add a regression test pinning one results file.
